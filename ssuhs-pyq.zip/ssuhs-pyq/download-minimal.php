<?php
$id = $_GET['id'] ?? 0;

if (!$id) {
    die('No ID provided');
}

try {
    $pdo = new PDO('mysql:host=localhost;dbname=ssuhs_pyq', 'root', '');
    $stmt = $pdo->prepare("SELECT * FROM pyq WHERE id = ?");
    $stmt->execute([$id]);
    $pyq = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$pyq) {
        die('PYQ not found');
    }
    
    // Create sample content
    $content = "SSUHS Previous Year Question Paper\n";
    $content .= "==================================\n\n";
    $content .= "Title: " . $pyq['title'] . "\n";
    $content .= "Course: " . strtoupper($pyq['course']) . "\n";
    $content .= "Subject: " . $pyq['subject'] . "\n";
    $content .= "Semester: " . $pyq['semester'] . "\n";
    $content .= "Year: " . $pyq['year'] . "\n\n";
    $content .= "Description: " . $pyq['description'] . "\n\n";
    $content .= "Sample Questions:\n";
    $content .= "1. Question about " . $pyq['subject'] . "\n";
    $content .= "2. Another question\n";
    $content .= "3. More questions here\n\n";
    $content .= "This is a sample file. Upload real PDFs through admin panel.";
    
    // Clean filename
    $filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $pyq['title']) . '.txt';
    
    // Send headers
    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($content));
    
    // Output content
    echo $content;
    
} catch (Exception $e) {
    die('Error: ' . $e->getMessage());
}
?>
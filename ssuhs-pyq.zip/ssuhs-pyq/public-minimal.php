<?php
$course = $_GET['course'] ?? '';

try {
    $pdo = new PDO('mysql:host=localhost;dbname=ssuhs_pyq', 'root', '');
    
    if ($course) {
        $stmt = $pdo->prepare("SELECT * FROM pyq WHERE course = ? ORDER BY year DESC");
        $stmt->execute([$course]);
        $pyqs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $pyqs = $pdo->query("SELECT * FROM pyq ORDER BY course, year DESC")->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get counts
    $mbbs = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'mbbs'")->fetchColumn();
    $nursing = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'bsc-nursing'")->fetchColumn();
    $bmlt = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'bmlt'")->fetchColumn();
    $pharmacy = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'pharmacy'")->fetchColumn();
    
} catch (Exception $e) {
    die('Database error: ' . $e->getMessage());
}
?>

<h1>SSUHS Previous Year Questions</h1>
<p><a href="admin-minimal.php">Admin Login</a></p>

<?php if (!$course): ?>
<h2>Select Course</h2>
<p><a href="?course=mbbs">MBBS (<?php echo $mbbs; ?> papers)</a></p>
<p><a href="?course=bsc-nursing">BSC Nursing (<?php echo $nursing; ?> papers)</a></p>
<p><a href="?course=bmlt">BMLT (<?php echo $bmlt; ?> papers)</a></p>
<p><a href="?course=pharmacy">Pharmacy (<?php echo $pharmacy; ?> papers)</a></p>
<?php else: ?>
<p><a href="public-minimal.php">← Back to All Courses</a></p>
<h2><?php echo strtoupper($course); ?> Question Papers</h2>
<?php endif; ?>

<?php if ($pyqs): ?>
<table border="1" cellpadding="10">
    <tr>
        <th>Title</th>
        <th>Course</th>
        <th>Subject</th>
        <th>Semester</th>
        <th>Year</th>
        <th>Download</th>
    </tr>
    <?php foreach ($pyqs as $pyq): ?>
    <tr>
        <td><?php echo htmlspecialchars($pyq['title']); ?></td>
        <td><?php echo strtoupper($pyq['course']); ?></td>
        <td><?php echo htmlspecialchars($pyq['subject']); ?></td>
        <td><?php echo $pyq['semester']; ?></td>
        <td><?php echo $pyq['year']; ?></td>
        <td><a href="download-minimal.php?id=<?php echo $pyq['id']; ?>">Download</a></td>
    </tr>
    <?php endforeach; ?>
</table>
<?php else: ?>
<p>No question papers found.</p>
<?php endif; ?>
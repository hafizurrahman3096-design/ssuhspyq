<?php
// Database Setup Script for SSUHS PYQ System
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'ssuhs_pyq';

echo "<!DOCTYPE html>
<html>
<head>
    <title>SSUHS PYQ Database Setup</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .success { color: #27ae60; background: #d5f4e6; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: #3498db; background: #ebf3fd; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .step { background: #f8f9fa; padding: 15px; border-left: 4px solid #3498db; margin: 15px 0; }
        h1 { color: #2c3e50; }
        h2 { color: #34495e; }
        .credentials { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }
    </style>
</head>
<body>";

echo "<h1>🚀 SSUHS PYQ Database Setup</h1>";

try {
    echo "<div class='step'><h2>Step 1: Connecting to MySQL Server</h2>";
    
    // Connect to MySQL server (without database)
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<div class='success'>✅ Successfully connected to MySQL server</div>";
    
    echo "</div><div class='step'><h2>Step 2: Creating Database</h2>";
    
    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS $database CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "<div class='success'>✅ Database '$database' created successfully</div>";
    
    // Select database
    $pdo->exec("USE $database");
    echo "<div class='success'>✅ Database '$database' selected</div>";
    
    echo "</div><div class='step'><h2>Step 3: Creating Admin Table</h2>";
    
    // Create admin table
    $adminTable = "CREATE TABLE IF NOT EXISTS admin (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($adminTable);
    echo "<div class='success'>✅ Admin table created successfully</div>";
    
    echo "</div><div class='step'><h2>Step 4: Creating PYQ Table</h2>";
    
    // Create pyq table
    $pyqTable = "CREATE TABLE IF NOT EXISTS pyq (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        course ENUM('mbbs', 'bsc-nursing', 'bmlt', 'pharmacy') NOT NULL,
        subject VARCHAR(100) NOT NULL,
        semester INT NOT NULL CHECK (semester >= 1 AND semester <= 8),
        year INT NOT NULL CHECK (year >= 2000 AND year <= 2030),
        description TEXT,
        file_path VARCHAR(255) NOT NULL,
        uploaded_by INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (uploaded_by) REFERENCES admin(id) ON DELETE SET NULL,
        INDEX idx_course (course),
        INDEX idx_semester (semester),
        INDEX idx_year (year),
        INDEX idx_subject (subject)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($pyqTable);
    echo "<div class='success'>✅ PYQ table created successfully</div>";
    
    echo "</div><div class='step'><h2>Step 5: Creating Default Admin User</h2>";
    
    // Check if admin user exists
    $checkAdmin = $pdo->prepare("SELECT COUNT(*) FROM admin WHERE username = ?");
    $checkAdmin->execute(['admin']);
    
    if ($checkAdmin->fetchColumn() == 0) {
        // Create default admin user
        $defaultPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $insertAdmin = $pdo->prepare("INSERT INTO admin (username, password, email) VALUES (?, ?, ?)");
        $insertAdmin->execute(['admin', $defaultPassword, 'admin@ssuhs.edu']);
        echo "<div class='success'>✅ Default admin user created</div>";
    } else {
        echo "<div class='info'>ℹ️ Admin user already exists</div>";
    }
    
    echo "</div><div class='step'><h2>Step 6: Inserting Sample Data</h2>";
    
    // Insert sample PYQ data
    $sampleData = [
        ['MBBS Anatomy 2023', 'mbbs', 'Anatomy', 1, 2023, 'Human anatomy question paper for first semester'],
        ['MBBS Physiology 2023', 'mbbs', 'Physiology', 2, 2023, 'Human physiology question paper for second semester'],
        ['BSC Nursing Fundamentals 2023', 'bsc-nursing', 'Nursing Fundamentals', 1, 2023, 'Basic nursing fundamentals question paper'],
        ['BMLT Clinical Pathology 2023', 'bmlt', 'Clinical Pathology', 3, 2023, 'Clinical pathology question paper'],
        ['Pharmacy Pharmaceutics 2023', 'pharmacy', 'Pharmaceutics', 1, 2023, 'Basic pharmaceutics question paper']
    ];
    
    $insertPYQ = $pdo->prepare("INSERT IGNORE INTO pyq (title, course, subject, semester, year, description, file_path, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    
    $sampleCount = 0;
    foreach ($sampleData as $data) {
        $fileName = strtolower(str_replace(' ', '_', $data[0])) . '.pdf';
        $result = $insertPYQ->execute([
            $data[0], $data[1], $data[2], $data[3], $data[4], $data[5], $fileName, 1
        ]);
        if ($result) $sampleCount++;
    }
    
    echo "<div class='success'>✅ $sampleCount sample PYQ records inserted</div>";
    
    echo "</div><div class='step'><h2>Step 7: Creating Uploads Directory</h2>";
    
    // Create uploads directory
    $uploadsDir = 'uploads';
    if (!is_dir($uploadsDir)) {
        mkdir($uploadsDir, 0755, true);
        echo "<div class='success'>✅ Uploads directory created</div>";
    } else {
        echo "<div class='info'>ℹ️ Uploads directory already exists</div>";
    }
    
    // Create .htaccess for uploads security
    $htaccessContent = "# Prevent direct access to uploaded files
Options -Indexes
<Files *.php>
    Deny from all
</Files>
<Files *.html>
    Deny from all
</Files>";
    
    file_put_contents($uploadsDir . '/.htaccess', $htaccessContent);
    echo "<div class='success'>✅ Security .htaccess file created in uploads directory</div>";
    
    echo "</div><div class='step'><h2>Step 8: Database Verification</h2>";
    
    // Verify tables
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "<div class='success'>✅ Tables created: " . implode(', ', $tables) . "</div>";
    
    // Count records
    $adminCount = $pdo->query("SELECT COUNT(*) FROM admin")->fetchColumn();
    $pyqCount = $pdo->query("SELECT COUNT(*) FROM pyq")->fetchColumn();
    
    echo "<div class='success'>✅ Admin users: $adminCount</div>";
    echo "<div class='success'>✅ PYQ records: $pyqCount</div>";
    
    echo "</div>";
    
    // Success message with credentials
    echo "<div class='credentials'>
        <h2>🎉 Database Setup Complete!</h2>
        <h3>Admin Login Credentials:</h3>
        <p><strong>Username:</strong> admin</p>
        <p><strong>Password:</strong> admin123</p>
        <p><strong>Admin URL:</strong> <a href='admin/'>http://localhost/ssuhs-pyq/admin/</a></p>
        <p><strong>Direct Login:</strong> <a href='backend/auth/login.php'>http://localhost/ssuhs-pyq/backend/auth/login.php</a></p>
    </div>";
    
    echo "<div class='info'>
        <h3>Next Steps:</h3>
        <ol>
            <li>Visit the <a href='index.html'>main website</a> to test the public interface</li>
            <li>Login to the <a href='admin/'>admin panel</a> to manage PYQs</li>
            <li>Upload some actual PYQ files through the admin interface</li>
            <li>Test all course pages (MBBS, BSC Nursing, BMLT, Pharmacy)</li>
        </ol>
    </div>";
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database Error: " . $e->getMessage() . "</div>";
    echo "<div class='info'>
        <h3>Common Solutions:</h3>
        <ul>
            <li>Make sure XAMPP/WAMP is running</li>
            <li>Check if MySQL service is started</li>
            <li>Verify database credentials in the script</li>
            <li>Ensure you have proper permissions</li>
        </ul>
    </div>";
} catch (Exception $e) {
    echo "<div class='error'>❌ General Error: " . $e->getMessage() . "</div>";
}

echo "<div style='margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 5px;'>
    <h3>🔧 Troubleshooting</h3>
    <p>If you encounter any issues:</p>
    <ul>
        <li>Refresh this page to run the setup again</li>
        <li>Check XAMPP Control Panel - Apache and MySQL should be running</li>
        <li>Visit <a href='backend/test-login.php'>test-login.php</a> to verify the setup</li>
        <li>Check the error logs in XAMPP</li>
    </ul>
</div>";

echo "</body></html>";
?>
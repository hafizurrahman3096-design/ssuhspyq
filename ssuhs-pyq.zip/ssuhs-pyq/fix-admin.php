<?php
require_once 'backend/config/database.php';

try {
    $pdo = getConnection();
    
    // Check if admin user exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM admin WHERE username = ?");
    $stmt->execute(['admin']);
    $count = $stmt->fetchColumn();
    
    echo "Admin users found: " . $count . "\n";
    
    if ($count == 0) {
        // Create admin user
        $hash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO admin (username, password, email, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute(['admin', $hash, 'admin@ssuhs.edu']);
        echo "Admin user created successfully!\n";
    } else {
        // Test the existing password
        $stmt = $pdo->prepare("SELECT password FROM admin WHERE username = ?");
        $stmt->execute(['admin']);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($admin && password_verify('admin123', $admin['password'])) {
            echo "Password verification: SUCCESS\n";
        } else {
            echo "Password verification: FAILED - Updating password\n";
            $hash = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE admin SET password = ? WHERE username = ?");
            $stmt->execute([$hash, 'admin']);
            echo "Password updated successfully!\n";
        }
    }
    
    echo "Login credentials:\n";
    echo "Username: admin\n";
    echo "Password: admin123\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>

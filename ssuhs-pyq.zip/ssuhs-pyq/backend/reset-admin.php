<?php
require_once 'config/database.php';

echo "<h2>Admin Password Reset Tool</h2>";

try {
    $pdo = getConnection();
    
    // Reset admin password
    $newPassword = 'admin123';
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    
    // Check if admin exists
    $checkStmt = $pdo->prepare("SELECT id FROM admin WHERE username = 'admin'");
    $checkStmt->execute();
    
    if ($checkStmt->rowCount() > 0) {
        // Update existing admin
        $updateStmt = $pdo->prepare("UPDATE admin SET password = ? WHERE username = 'admin'");
        $updateStmt->execute([$hashedPassword]);
        echo "<p>✅ Admin password has been reset successfully!</p>";
    } else {
        // Create new admin
        $insertStmt = $pdo->prepare("INSERT INTO admin (username, password, email) VALUES (?, ?, ?)");
        $insertStmt->execute(['admin', $hashedPassword, 'admin@ssuhs.edu']);
        echo "<p>✅ New admin account created successfully!</p>";
    }
    
    echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>🔑 Login Credentials:</h3>";
    echo "<p><strong>Username:</strong> admin</p>";
    echo "<p><strong>Password:</strong> admin123</p>";
    echo "<p><strong>Login URL:</strong> <a href='../admin/'>http://localhost/ssuhs-pyq/admin</a></p>";
    echo "</div>";
    
    // Test the password
    $testStmt = $pdo->prepare("SELECT password FROM admin WHERE username = 'admin'");
    $testStmt->execute();
    $adminData = $testStmt->fetch(PDO::FETCH_ASSOC);
    
    if (password_verify('admin123', $adminData['password'])) {
        echo "<p>✅ Password verification test: PASSED</p>";
    } else {
        echo "<p>❌ Password verification test: FAILED</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<br><br>";
echo "<a href='../admin/' style='background: #3498db; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Admin Panel</a>";
echo " ";
echo "<a href='auth/login.php' style='background: #27ae60; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Login Page</a>";
?>
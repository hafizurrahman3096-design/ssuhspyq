<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

try {
    $pdo = getConnection();
    
    $course = $_GET['course'] ?? '';
    $semester = $_GET['semester'] ?? '';
    
    if (empty($course)) {
        echo json_encode(['success' => false, 'message' => 'Course parameter is required']);
        exit;
    }
    
    // Validate course
    $validCourses = ['mbbs', 'bsc-nursing', 'bmlt', 'pharmacy'];
    if (!in_array($course, $validCourses)) {
        echo json_encode(['success' => false, 'message' => 'Invalid course']);
        exit;
    }
    
    // Build query based on parameters
    $query = "SELECT * FROM pyq WHERE course = ?";
    $params = [$course];
    
    if (!empty($semester)) {
        $query .= " AND semester = ?";
        $params[] = $semester;
    }
    
    $query .= " ORDER BY semester ASC, year DESC, subject ASC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $pyqs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get available semesters for this course
    $semesterStmt = $pdo->prepare("SELECT DISTINCT semester FROM pyq WHERE course = ? ORDER BY semester ASC");
    $semesterStmt->execute([$course]);
    $semesters = $semesterStmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo json_encode([
        'success' => true,
        'pyqs' => $pyqs,
        'semesters' => $semesters
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching PYQs: ' . $e->getMessage()
    ]);
}
?>
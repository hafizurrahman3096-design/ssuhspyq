<?php
// Save theme preference to database
session_start();
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

// Get theme from request
$data = json_decode(file_get_contents('php://input'), true);
$theme = $data['theme'] ?? 'light';

// Validate theme
if (!in_array($theme, ['light', 'dark'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid theme']);
    exit;
}

// Database connection
require_once '../config/database.php';

try {
    // Update user's theme preference
    $stmt = $pdo->prepare("UPDATE admin_users SET theme_preference = ? WHERE id = ?");
    $result = $stmt->execute([$theme, $_SESSION['admin_id']]);
    
    if ($result) {
        echo json_encode(['success' => true, 'theme' => $theme]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save theme']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>

<?php
require_once 'config/database.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Database Migration</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        .success { color: #27ae60; background: #d5f4e6; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: #3498db; background: #ebf3fd; padding: 10px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>";

echo "<h1>🔄 Database Migration</h1>";

try {
    $pdo = getConnection();
    
    // Check if semester column exists
    $result = $pdo->query("SHOW COLUMNS FROM pyq LIKE 'semester'");
    
    if ($result->rowCount() == 0) {
        // Add semester column
        $pdo->exec("ALTER TABLE pyq ADD COLUMN semester INT NOT NULL DEFAULT 1 AFTER subject");
        echo "<div class='success'>✅ Added semester column to pyq table</div>";
        
        // Update existing records
        $pdo->exec("UPDATE pyq SET semester = 1 WHERE semester IS NULL OR semester = 0");
        echo "<div class='success'>✅ Updated existing records with default semester values</div>";
    } else {
        echo "<div class='info'>ℹ️ Semester column already exists</div>";
    }
    
    // Check if pharmacy is in course enum
    $result = $pdo->query("SHOW COLUMNS FROM pyq WHERE Field = 'course'");
    $courseColumn = $result->fetch(PDO::FETCH_ASSOC);
    
    if ($courseColumn && strpos($courseColumn['Type'], 'pharmacy') === false) {
        // Add pharmacy to course enum
        $pdo->exec("ALTER TABLE pyq MODIFY COLUMN course ENUM('mbbs', 'bsc-nursing', 'bmlt', 'pharmacy') NOT NULL");
        echo "<div class='success'>✅ Added pharmacy to course options</div>";
    } else {
        echo "<div class='info'>ℹ️ Pharmacy course option already exists</div>";
    }
    
    echo "<div class='success'><h2>✅ Migration completed successfully!</h2></div>";
    echo "<div class='info'>
        <p>You can now:</p>
        <ul>
            <li><a href='../admin/'>Access the admin panel</a></li>
            <li><a href='../index.html'>Visit the main website</a></li>
        </ul>
    </div>";
    
} catch (Exception $e) {
    echo "<div class='error'>❌ Migration failed: " . $e->getMessage() . "</div>";
    echo "<div class='info'>
        <p>Try running the <a href='../fix-database.php'>database fix script</a> instead.</p>
    </div>";
}

echo "</body></html>";
?>
<?php
require_once 'config/database.php';

echo "<h2>Testing Admin Login System</h2>";

try {
    $pdo = getConnection();
    
    // Check if admin table exists
    $result = $pdo->query("SHOW TABLES LIKE 'admin'");
    if ($result->rowCount() > 0) {
        echo "<p>✓ Admin table exists</p>";
        
        // Check admin users
        $admins = $pdo->query("SELECT id, username, email, created_at FROM admin")->fetchAll(PDO::FETCH_ASSOC);
        echo "<p>✓ Found " . count($admins) . " admin user(s):</p>";
        
        foreach ($admins as $admin) {
            echo "<ul>";
            echo "<li>ID: " . $admin['id'] . "</li>";
            echo "<li>Username: " . $admin['username'] . "</li>";
            echo "<li>Email: " . $admin['email'] . "</li>";
            echo "<li>Created: " . $admin['created_at'] . "</li>";
            echo "</ul><br>";
        }
        
        // Test password verification
        $stmt = $pdo->prepare("SELECT password FROM admin WHERE username = 'admin'");
        $stmt->execute();
        $adminData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($adminData) {
            $testPassword = 'admin123';
            if (password_verify($testPassword, $adminData['password'])) {
                echo "<p>✓ Password verification works correctly</p>";
            } else {
                echo "<p>✗ Password verification failed</p>";
                echo "<p>Resetting admin password...</p>";
                
                $newPassword = password_hash('admin123', PASSWORD_DEFAULT);
                $updateStmt = $pdo->prepare("UPDATE admin SET password = ? WHERE username = 'admin'");
                $updateStmt->execute([$newPassword]);
                echo "<p>✓ Admin password reset to 'admin123'</p>";
            }
        }
        
    } else {
        echo "<p>✗ Admin table does not exist</p>";
    }
    
    // Check pyq table
    $result = $pdo->query("SHOW TABLES LIKE 'pyq'");
    if ($result->rowCount() > 0) {
        echo "<p>✓ PYQ table exists</p>";
        
        // Check course enum
        $result = $pdo->query("SHOW COLUMNS FROM pyq LIKE 'course'");
        $courseColumn = $result->fetch(PDO::FETCH_ASSOC);
        echo "<p>✓ Course column type: " . $courseColumn['Type'] . "</p>";
        
        // Check semester column
        $result = $pdo->query("SHOW COLUMNS FROM pyq LIKE 'semester'");
        if ($result->rowCount() > 0) {
            echo "<p>✓ Semester column exists</p>";
        } else {
            echo "<p>✗ Semester column missing</p>";
        }
    } else {
        echo "<p>✗ PYQ table does not exist</p>";
    }
    
} catch (Exception $e) {
    echo "<p>✗ Error: " . $e->getMessage() . "</p>";
}

echo "<br><a href='../admin/dashboard.php'>Go to Admin Dashboard</a>";
echo "<br><a href='auth/login.php'>Go to Login Page</a>";
?>
<?php
// Debug script to identify the internal server error
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

echo "<!DOCTYPE html>
<html>
<head>
    <title>Debug - SSUHS PYQ</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 20px auto; padding: 20px; }
        .success { color: #27ae60; background: #d5f4e6; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: #3498db; background: #ebf3fd; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .warning { color: #f39c12; background: #fef9e7; padding: 10px; border-radius: 5px; margin: 10px 0; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>";

echo "<h1>🔍 SSUHS PYQ Debug Information</h1>";

// Check PHP version
echo "<div class='info'><strong>PHP Version:</strong> " . phpversion() . "</div>";

// Check if MySQL extension is loaded
if (extension_loaded('pdo_mysql')) {
    echo "<div class='success'>✅ PDO MySQL extension is loaded</div>";
} else {
    echo "<div class='error'>❌ PDO MySQL extension is NOT loaded</div>";
}

// Test basic MySQL connection
echo "<h2>🔌 Database Connection Test</h2>";

try {
    $pdo = new PDO('mysql:host=localhost', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<div class='success'>✅ MySQL server connection: SUCCESS</div>";
    
    // Check if database exists
    $databases = $pdo->query("SHOW DATABASES LIKE 'ssuhs_pyq'")->fetchAll();
    if (count($databases) > 0) {
        echo "<div class='success'>✅ Database 'ssuhs_pyq' exists</div>";
        
        // Connect to specific database
        $pdo = new PDO('mysql:host=localhost;dbname=ssuhs_pyq', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Check tables
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($tables)) {
            echo "<div class='success'>✅ Tables found: " . implode(', ', $tables) . "</div>";
            
            // Check pyq table structure
            if (in_array('pyq', $tables)) {
                $columns = $pdo->query("SHOW COLUMNS FROM pyq")->fetchAll(PDO::FETCH_ASSOC);
                $columnNames = array_column($columns, 'Field');
                echo "<div class='info'>PYQ table columns: " . implode(', ', $columnNames) . "</div>";
                
                if (in_array('semester', $columnNames)) {
                    echo "<div class='success'>✅ Semester column exists</div>";
                } else {
                    echo "<div class='warning'>⚠️ Semester column missing</div>";
                }
            }
            
        } else {
            echo "<div class='warning'>⚠️ No tables found in database</div>";
        }
        
    } else {
        echo "<div class='warning'>⚠️ Database 'ssuhs_pyq' does not exist</div>";
    }
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database connection failed: " . $e->getMessage() . "</div>";
}

// Test file includes
echo "<h2>📁 File System Test</h2>";

$files_to_check = [
    'index.html',
    'backend/config/database.php',
    'backend/auth/login.php',
    'admin/dashboard.php',
    'css/admin.css'
];

foreach ($files_to_check as $file) {
    if (file_exists($file)) {
        echo "<div class='success'>✅ $file exists</div>";
    } else {
        echo "<div class='error'>❌ $file missing</div>";
    }
}

// Test backend config include
echo "<h2>🔧 Backend Configuration Test</h2>";

try {
    if (file_exists('backend/config/database.php')) {
        // Don't include it directly as it might cause errors
        $content = file_get_contents('backend/config/database.php');
        if (strpos($content, '<?php') !== false) {
            echo "<div class='success'>✅ Database config file has valid PHP opening tag</div>";
        } else {
            echo "<div class='error'>❌ Database config file missing PHP opening tag</div>";
        }
        
        if (strpos($content, 'getConnection') !== false) {
            echo "<div class='success'>✅ getConnection function found in config</div>";
        } else {
            echo "<div class='error'>❌ getConnection function missing in config</div>";
        }
    } else {
        echo "<div class='error'>❌ Database config file not found</div>";
    }
} catch (Exception $e) {
    echo "<div class='error'>❌ Error checking config file: " . $e->getMessage() . "</div>";
}

// Check Apache modules
echo "<h2>🌐 Apache Configuration</h2>";

if (function_exists('apache_get_modules')) {
    $modules = apache_get_modules();
    if (in_array('mod_rewrite', $modules)) {
        echo "<div class='success'>✅ mod_rewrite is enabled</div>";
    } else {
        echo "<div class='warning'>⚠️ mod_rewrite might not be enabled</div>";
    }
} else {
    echo "<div class='info'>ℹ️ Cannot check Apache modules (not running under Apache or function not available)</div>";
}

// Check .htaccess
if (file_exists('.htaccess')) {
    echo "<div class='success'>✅ .htaccess file exists</div>";
} else {
    echo "<div class='warning'>⚠️ .htaccess file missing</div>";
}

// Show PHP error log if available
echo "<h2>📋 Recent PHP Errors</h2>";

$error_log = ini_get('error_log');
if ($error_log && file_exists($error_log)) {
    $errors = file_get_contents($error_log);
    $recent_errors = array_slice(explode("\n", $errors), -10);
    echo "<pre>" . htmlspecialchars(implode("\n", $recent_errors)) . "</pre>";
} else {
    echo "<div class='info'>ℹ️ No error log found or accessible</div>";
}

echo "<h2>🚀 Next Steps</h2>";
echo "<div class='info'>
    <p>Based on the results above:</p>
    <ul>
        <li>If database connection failed: <a href='setup-database.php'>Run Database Setup</a></li>
        <li>If semester column missing: <a href='fix-database.php'>Run Database Fix</a></li>
        <li>If files missing: Check your file structure</li>
        <li>If everything looks good: Try accessing <a href='admin/'>Admin Panel</a></li>
    </ul>
</div>";

echo "</body></html>";
?>
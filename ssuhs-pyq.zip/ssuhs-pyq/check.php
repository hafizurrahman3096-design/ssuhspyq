<?php
// Ultra-simple PHP check
phpinfo();
?>
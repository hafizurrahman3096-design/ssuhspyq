<?php
// Ultra-simple database setup
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'ssuhs_pyq';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Simple Setup</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 20px auto; padding: 20px; }
        .success { color: #27ae60; background: #d5f4e6; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: #3498db; background: #ebf3fd; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .btn { display: inline-block; background: #3498db; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px; }
    </style>
</head>
<body>";

echo "<h1>🚀 Simple Database Setup</h1>";

try {
    // Connect and create database
    $pdo = new PDO("mysql:host=$host", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS $dbname");
    $pdo->exec("USE $dbname");
    echo "<div class='success'>✅ Database created/selected</div>";
    
    // Create admin table
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    echo "<div class='success'>✅ Admin table created</div>";
    
    // Create pyq table
    $pdo->exec("CREATE TABLE IF NOT EXISTS pyq (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        course VARCHAR(50) NOT NULL,
        subject VARCHAR(100) NOT NULL,
        semester INT DEFAULT 1,
        year INT NOT NULL,
        description TEXT,
        file_path VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    echo "<div class='success'>✅ PYQ table created</div>";
    
    // Insert admin user
    $adminExists = $pdo->query("SELECT COUNT(*) FROM admin WHERE username = 'admin'")->fetchColumn();
    if ($adminExists == 0) {
        $password = password_hash('admin123', PASSWORD_DEFAULT);
        $pdo->prepare("INSERT INTO admin (username, password) VALUES (?, ?)")->execute(['admin', $password]);
        echo "<div class='success'>✅ Admin user created</div>";
    } else {
        echo "<div class='info'>ℹ️ Admin user already exists</div>";
    }
    
    // Insert sample data
    $sampleData = [
        ['MBBS Anatomy 2023', 'mbbs', 'Anatomy', 1, 2023, 'Sample anatomy paper', 'anatomy_2023.pdf'],
        ['BSC Nursing 2023', 'bsc-nursing', 'Nursing', 1, 2023, 'Sample nursing paper', 'nursing_2023.pdf'],
        ['BMLT Lab 2023', 'bmlt', 'Laboratory', 2, 2023, 'Sample lab paper', 'lab_2023.pdf'],
        ['Pharmacy 2023', 'pharmacy', 'Pharmaceutics', 1, 2023, 'Sample pharmacy paper', 'pharmacy_2023.pdf']
    ];
    
    $insertCount = 0;
    foreach ($sampleData as $data) {
        $existing = $pdo->prepare("SELECT COUNT(*) FROM pyq WHERE title = ?");
        $existing->execute([$data[0]]);
        if ($existing->fetchColumn() == 0) {
            $stmt = $pdo->prepare("INSERT INTO pyq (title, course, subject, semester, year, description, file_path) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute($data);
            $insertCount++;
        }
    }
    echo "<div class='success'>✅ Inserted $insertCount sample records</div>";
    
    // Create uploads directory
    if (!is_dir('uploads')) {
        mkdir('uploads', 0755, true);
        echo "<div class='success'>✅ Uploads directory created</div>";
    }
    
    echo "<div class='success'>
        <h2>🎉 Setup Complete!</h2>
        <p><strong>Login:</strong> admin / admin123</p>
    </div>";
    
    echo "<div style='text-align: center;'>
        <a href='admin-simple.php' class='btn'>🚀 Go to Admin Panel</a>
        <a href='view-pyq.php' class='btn'>📋 View PYQs</a>
    </div>";
    
} catch (Exception $e) {
    echo "<div class='error'>❌ Error: " . $e->getMessage() . "</div>";
}

echo "</body></html>";
?>
# Free Hosting Guide for SSUHS PYQ

## Option 1: 000webhost (Recommended)

### Steps:
1. **Sign Up**: Go to [000webhost.com](https://www.000webhost.com)
2. **Create Account**: Free registration
3. **Choose Website**: Select "Upload Website"
4. **Set Domain**: Choose free subdomain (your-site.000webhostapp.com)

### Upload Files:
1. Go to File Manager in control panel
2. Upload all your files to `public_html`
3. Extract if you uploaded a zip file

### Database Setup:
1. Go to "MySQL Database" in control panel
2. Create new database
3. Create database user
4. Import your database using phpMyAdmin

### Configuration:
Update `backend/config/database.php`:
```php
$host = 'localhost';
$dbname = 'your_000webhost_db';
$username = 'your_000webhost_user';
$password = 'your_000webhost_password';
```

## Option 2: InfinityFree

### Steps:
1. **Sign Up**: [InfinityFree.net](https://infinityfree.net)
2. **Create Account**: Free registration
3. **Choose Domain**: Free subdomain
4. **Control Panel**: cPanel access

### Setup Process:
1. Upload files via File Manager
2. Create MySQL database
3. Import database
4. Update configuration

## Option 3: Render (Modern)

### Steps:
1. **Sign Up**: [Render.com](https://render.com)
2. **Create Web Service**
3. **Connect GitHub** (upload code to GitHub first)
4. **Configure Environment Variables**

### Requirements:
- Upload code to GitHub
- Create `render.yaml` file
- Set up PostgreSQL instead of MySQL

## Option 4: Heroku (Free Tier)

### Steps:
1. **Install Heroku CLI**
2. **Create `composer.json`**
3. **Create `Procfile`**
4. **Deploy via Git**

### Files Needed:
```json
// composer.json
{
    "require": {
        "php": ">=7.4"
    }
}
```

```
# Procfile
web: heroku-php-apache2 public/
```

## Option 5: GitHub Pages + External Backend

### Frontend on GitHub Pages:
1. Create GitHub repository
2. Upload HTML/CSS/JS files
3. Enable GitHub Pages
4. Backend on separate free service

## Preparation Steps:

### 1. Backup Your Database
```bash
mysqldump -u root -p ssuhs_pyq > backup.sql
```

### 2. Create Deployment Package
```bash
# Exclude unnecessary files
zip -r ssuhs-pyq-deploy.zip . -x "*/.git/*" "*/node_modules/*" "*/backup/*"
```

### 3. Update Configuration
- Remove hardcoded localhost references
- Make database credentials configurable
- Update file paths for production

### 4. Test Locally
- Ensure everything works before deployment
- Test with production-like settings

## Free Hosting Limitations:

### 000webhost:
- 1GB storage
- 1GB bandwidth/month
- Ads on free plan
- Limited database size

### InfinityFree:
- 400MB storage
- 50GB bandwidth/month
- No ads
- Limited resources

### Render:
- 750 hours/month
- Sleeps after 15 minutes inactivity
- Limited to PostgreSQL

### Heroku:
- 550-1000 dyno hours/month
- Sleeps after 30 minutes
- Limited database size

## Recommended Setup:

### For Beginners: 000webhost
- Easiest setup
- PHP + MySQL support
- cPanel interface
- Good for learning

### For Developers: Render
- Modern platform
- Git integration
- Automatic SSL
- Better performance

## Security Tips:

1. **Change Default Credentials**
   - Update admin username/password
   - Use strong database passwords

2. **File Permissions**
   - Set proper folder permissions
   - Protect sensitive files

3. **Database Security**
   - Use different table prefixes
   - Limit database user privileges

4. **SSL Certificate**
   - Enable HTTPS if available
   - Update all URLs to HTTPS

## Troubleshooting:

### Common Issues:
- **500 Internal Server Error**: Check .htaccess file
- **Database Connection Failed**: Verify credentials
- **File Upload Issues**: Check folder permissions
- **Blank Pages**: Enable error logging

### Debug Steps:
1. Check error logs
2. Verify file permissions
3. Test database connection
4. Check PHP version compatibility

## Migration Steps:

1. **Choose Hosting Provider**
2. **Create Account**
3. **Prepare Files**
4. **Set Up Database**
5. **Upload Files**
6. **Configure Application**
7. **Test Everything**
8. **Update DNS (if using custom domain)**

## Next Steps:

After successful deployment:
1. Monitor performance
2. Set up backups
3. Consider upgrade to paid plan
4. Optimize for speed
5. Add analytics

## Support Resources:

- **000webhost**: Community forum, knowledge base
- **InfinityFree**: Discord community, documentation
- **Render**: Documentation, community support
- **Heroku**: Extensive documentation, dev center

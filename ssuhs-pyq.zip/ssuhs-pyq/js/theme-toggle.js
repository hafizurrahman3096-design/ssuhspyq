// Dark Mode Toggle Functionality
class ThemeToggle {
    constructor() {
        this.init();
    }

    init() {
        // Load saved theme or default to light
        const savedTheme = localStorage.getItem('theme') || 'light';
        this.setTheme(savedTheme);

        // Create and add toggle button to navigation
        this.createToggleButton();

        // Add keyboard shortcut (Ctrl/Cmd + Shift + D)
        this.addKeyboardShortcut();
    }

    createToggleButton() {
        const navRight = document.querySelector('.dashboard-nav > div:last-child');
        if (!navRight) return;

        // Create theme toggle button
        const toggleBtn = document.createElement('button');
        toggleBtn.className = 'theme-toggle';
        toggleBtn.setAttribute('aria-label', 'Toggle dark mode');
        toggleBtn.innerHTML = `
            <i class="fas fa-${this.getCurrentTheme() === 'dark' ? 'sun' : 'moon'}"></i>
            <span>${this.getCurrentTheme() === 'dark' ? 'Light' : 'Dark'}</span>
        `;

        // Insert before the user info
        const userSpan = navRight.querySelector('span');
        if (userSpan) {
            navRight.insertBefore(toggleBtn, userSpan);
        } else {
            navRight.appendChild(toggleBtn);
        }

        // Add click event
        toggleBtn.addEventListener('click', () => this.toggleTheme());
    }

    toggleTheme() {
        const currentTheme = this.getCurrentTheme();
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        this.setTheme(newTheme);
        this.updateToggleButton(newTheme);
        this.saveTheme(newTheme);
        
        // Add transition effect
        this.addTransitionEffect();
    }

    setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        document.body.classList.toggle('dark-mode', theme === 'dark');
    }

    getCurrentTheme() {
        return document.documentElement.getAttribute('data-theme') || 'light';
    }

    updateToggleButton(theme) {
        const toggleBtn = document.querySelector('.theme-toggle');
        if (!toggleBtn) return;

        const icon = toggleBtn.querySelector('i');
        const text = toggleBtn.querySelector('span');

        if (theme === 'dark') {
            icon.className = 'fas fa-sun';
            text.textContent = 'Light';
        } else {
            icon.className = 'fas fa-moon';
            text.textContent = 'Dark';
        }
    }

    saveTheme(theme) {
        localStorage.setItem('theme', theme);
        
        // Save theme preference to server if user is logged in
        if (typeof fetch !== 'undefined') {
            fetch('../backend/api/save-theme.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ theme: theme })
            }).catch(err => console.log('Could not save theme to server'));
        }
    }

    addKeyboardShortcut() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + Shift + D
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'D') {
                e.preventDefault();
                this.toggleTheme();
            }
        });
    }

    addTransitionEffect() {
        // Add a subtle transition effect when switching themes
        document.body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
        
        setTimeout(() => {
            document.body.style.transition = '';
        }, 300);
    }

    // Auto-switch based on system preference
    enableSystemPreference() {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
        
        prefersDark.addEventListener('change', (e) => {
            if (!localStorage.getItem('theme')) {
                // Only auto-switch if user hasn't manually set a preference
                this.setTheme(e.matches ? 'dark' : 'light');
                this.updateToggleButton(e.matches ? 'dark' : 'light');
            }
        });

        // Set initial theme based on system preference
        if (!localStorage.getItem('theme')) {
            this.setTheme(prefersDark.matches ? 'dark' : 'light');
            this.updateToggleButton(prefersDark.matches ? 'dark' : 'light');
        }
    }
}

// Initialize theme toggle when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new ThemeToggle();
});

// Export for use in other scripts
window.ThemeToggle = ThemeToggle;

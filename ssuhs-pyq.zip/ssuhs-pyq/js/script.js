// Global variables
let currentCourse = '';
let allPYQs = [];
let availableSemesters = [];

// Redirect to course-specific page
function goToCourse(course) {
    window.location.href = `courses/${course}.html`;
}

// Load PYQ for selected course (for course-specific pages)
async function loadPYQ(course) {
    currentCourse = course;
    const courseNames = {
        'mbbs': 'MBBS',
        'bsc-nursing': 'BSC Nursing',
        'bmlt': 'BMLT',
        'pharmacy': 'Pharmacy'
    };
    
    document.getElementById('course-title').textContent = `${courseNames[course]} - Previous Year Questions`;
    document.getElementById('pyq-display').style.display = 'block';
    
    try {
        const response = await fetch(`../backend/api/get_pyq.php?course=${course}`);
        const data = await response.json();
        
        if (data.success) {
            allPYQs = data.pyqs;
            availableSemesters = data.semesters || [];
            populateFilters();
            displayPYQs(allPYQs);
        } else {
            document.getElementById('pyq-list').innerHTML = '<p>No questions available for this course.</p>';
        }
    } catch (error) {
        console.error('Error loading PYQs:', error);
        document.getElementById('pyq-list').innerHTML = '<p>Error loading questions. Please try again.</p>';
    }
}

// Populate filter dropdowns
function populateFilters() {
    const yearFilter = document.getElementById('year-filter');
    const subjectFilter = document.getElementById('subject-filter');
    const semesterFilter = document.getElementById('semester-filter');
    
    // Clear existing options
    yearFilter.innerHTML = '<option value="">All Years</option>';
    subjectFilter.innerHTML = '<option value="">All Subjects</option>';
    semesterFilter.innerHTML = '<option value="">All Semesters</option>';
    
    // Get unique years, subjects, and semesters
    const years = [...new Set(allPYQs.map(pyq => pyq.year))].sort((a, b) => b - a);
    const subjects = [...new Set(allPYQs.map(pyq => pyq.subject))].sort();
    const semesters = [...new Set(allPYQs.map(pyq => pyq.semester))].sort((a, b) => a - b);
    
    // Populate year filter
    years.forEach(year => {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearFilter.appendChild(option);
    });
    
    // Populate subject filter
    subjects.forEach(subject => {
        const option = document.createElement('option');
        option.value = subject;
        option.textContent = subject;
        subjectFilter.appendChild(option);
    });
    
    // Populate semester filter
    semesters.forEach(semester => {
        const option = document.createElement('option');
        option.value = semester;
        option.textContent = `Semester ${semester}`;
        semesterFilter.appendChild(option);
    });
}

// Display PYQs
function displayPYQs(pyqs) {
    const pyqList = document.getElementById('pyq-list');
    
    if (pyqs.length === 0) {
        pyqList.innerHTML = '<p>No questions found matching the selected filters.</p>';
        return;
    }
    
    pyqList.innerHTML = pyqs.map(pyq => `
        <div class="pyq-item">
            <div class="pyq-info">
                <h4>${pyq.title}</h4>
                <p><strong>Subject:</strong> ${pyq.subject} | <strong>Semester:</strong> ${pyq.semester} | <strong>Year:</strong> ${pyq.year} | <strong>Course:</strong> ${pyq.course.toUpperCase()}</p>
                <p><strong>Description:</strong> ${pyq.description || 'No description available'}</p>
            </div>
            <a href="uploads/${pyq.file_path}" class="download-btn" target="_blank">
                <i class="fas fa-download"></i> Download
            </a>
        </div>
    `).join('');
}

// Filter PYQs
function filterPYQs() {
    const yearFilter = document.getElementById('year-filter').value;
    const subjectFilter = document.getElementById('subject-filter').value;
    const semesterFilter = document.getElementById('semester-filter').value;
    
    let filteredPYQs = allPYQs;
    
    if (yearFilter) {
        filteredPYQs = filteredPYQs.filter(pyq => pyq.year == yearFilter);
    }
    
    if (subjectFilter) {
        filteredPYQs = filteredPYQs.filter(pyq => pyq.subject === subjectFilter);
    }
    
    if (semesterFilter) {
        filteredPYQs = filteredPYQs.filter(pyq => pyq.semester == semesterFilter);
    }
    
    displayPYQs(filteredPYQs);
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Only add filter event listeners if elements exist (on course pages)
    const yearFilter = document.getElementById('year-filter');
    const subjectFilter = document.getElementById('subject-filter');
    const semesterFilter = document.getElementById('semester-filter');
    
    if (yearFilter) yearFilter.addEventListener('change', filterPYQs);
    if (subjectFilter) subjectFilter.addEventListener('change', filterPYQs);
    if (semesterFilter) semesterFilter.addEventListener('change', filterPYQs);
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});

// Search functionality
function searchPYQs(searchTerm) {
    const filteredPYQs = allPYQs.filter(pyq => 
        pyq.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        pyq.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
        pyq.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
    displayPYQs(filteredPYQs);
}
<?php
echo "<h2>SSUHS PYQ Setup Test</h2>";

// Check if files exist
$files_to_check = [
    'index.html',
    'css/style.css',
    'js/script.js',
    'admin/login.php',
    'config/database.php',
    'uploads/'
];

echo "<h3>File Check:</h3>";
foreach ($files_to_check as $file) {
    if (file_exists($file)) {
        echo "✅ $file - Found<br>";
    } else {
        echo "❌ $file - Missing<br>";
    }
}

// Check PHP version
echo "<h3>PHP Version:</h3>";
echo "PHP Version: " . phpversion() . "<br>";

// Check database connection
echo "<h3>Database Test:</h3>";
try {
    require_once 'config/database.php';
    $pdo = getConnection();
    echo "✅ Database connection successful<br>";
} catch (Exception $e) {
    echo "❌ Database connection failed: " . $e->getMessage() . "<br>";
}

echo "<h3>Next Steps:</h3>";
echo "1. Go to <a href='index.html'>Main Website</a><br>";
echo "2. Go to <a href='admin/login.php'>Admin Panel</a><br>";
echo "3. Default admin login: admin / admin123<br>";
?>
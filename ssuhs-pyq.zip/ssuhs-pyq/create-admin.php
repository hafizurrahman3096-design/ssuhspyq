<?php
// Create admin user using mysqli (alternative to PDO)
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'ssuhs_pyq';

// Create connection
$conn = new mysqli($host, $user, $pass);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "MySQL connection: SUCCESS\n";

// Create database
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");
$conn->select_db($dbname);
echo "Database '$dbname' created/verified\n";

// Create admin table
$conn->query("CREATE TABLE IF NOT EXISTS admin (
    id int(11) NOT NULL AUTO_INCREMENT,
    username varchar(50) NOT NULL,
    password varchar(255) NOT NULL,
    email varchar(100) DEFAULT NULL,
    created_at timestamp NOT NULL DEFAULT current_timestamp(),
    PRIMARY KEY (id),
    UNIQUE KEY username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "Admin table created/verified\n";

// Check if admin exists
$result = $conn->query("SELECT COUNT(*) as count FROM admin WHERE username = 'admin'");
$row = $result->fetch_assoc();
$count = $row['count'];

if ($count == 0) {
    $hash = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO admin (username, password, email, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("sss", 'admin', $hash, 'admin@ssuhs.edu');
    $stmt->execute();
    echo "Admin user created successfully!\n";
} else {
    echo "Admin user already exists\n";
}

echo "\n=== LOGIN CREDENTIALS ===\n";
echo "Username: admin\n";
echo "Password: admin123\n";
echo "========================\n";

$conn->close();
?>

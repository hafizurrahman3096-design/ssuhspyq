<?php
session_start();
require_once '../backend/config/database.php';

// Check if logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../backend/auth/login.php');
    exit;
}

$success = '';
$error = '';

// Handle search and filters
$search = $_GET['search'] ?? '';
$courseFilter = $_GET['course'] ?? '';
$yearFilter = $_GET['year'] ?? '';

try {
    $pdo = getConnection();
    
    // Build query with filters
    $query = "SELECT * FROM pyq WHERE 1=1";
    $params = [];
    
    if (!empty($search)) {
        $query .= " AND (title LIKE ? OR subject LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    if (!empty($courseFilter)) {
        $query .= " AND course = ?";
        $params[] = $courseFilter;
    }
    
    if (!empty($yearFilter)) {
        $query .= " AND year = ?";
        $params[] = $yearFilter;
    }
    
    $query .= " ORDER BY created_at DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $pyqs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get unique years for filter
    $yearsStmt = $pdo->query("SELECT DISTINCT year FROM pyq ORDER BY year DESC");
    $years = $yearsStmt->fetchAll(PDO::FETCH_COLUMN);
    
} catch (Exception $e) {
    $error = "Error loading PYQs: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage PYQ - SSUHS Admin</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="dashboard">
    <script src="../js/theme-toggle.js"></script>
    <header class="dashboard-header">
        <nav class="dashboard-nav">
            <div class="university-logo">
                <img src="../courses/Srimanta_Sankaradeva_University_of_Health_Sciences_logo.png" alt="SSUHS Logo">
                <div class="logo-text">
                    <h1 class="main-title">SSUHS PYQ Admin</h1>
                    <p class="sub-title">Srimanta Sankaradeva University of Health Sciences</p>
                </div>
            </div>
            <ul class="nav-links">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="manage_pyq.php" class="active"><i class="fas fa-file-alt"></i> Manage PYQ</a></li>
                <li><a href="add_pyq.php"><i class="fas fa-plus"></i> Add PYQ</a></li>
                <li><a href="manage_notes.php"><i class="fas fa-sticky-note"></i> Manage Notes</a></li>
                <li><a href="add_note.php"><i class="fas fa-plus"></i> Add Note</a></li>
            </ul>
            <div>
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                <a href="../backend/auth/logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </header>

    <main class="dashboard-content">
        <div class="content-section">
            <div class="section-header">
                <h2>Manage PYQ</h2>
                <a href="add_pyq.php" class="btn btn-success">
                    <i class="fas fa-plus"></i> Add New PYQ
                </a>
            </div>

            <?php if ($success): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Search and Filter Form -->
            <form method="GET" class="form-grid" style="margin-bottom: 2rem;">
                <div class="form-group">
                    <label for="search">Search</label>
                    <input type="text" id="search" name="search" placeholder="Search by title or subject" value="<?php echo htmlspecialchars($search); ?>">
                </div>
                
                <div class="form-group">
                    <label for="course">Filter by Course</label>
                    <select id="course" name="course">
                        <option value="">All Courses</option>
                        <option value="mbbs" <?php echo $courseFilter === 'mbbs' ? 'selected' : ''; ?>>MBBS</option>
                        <option value="bsc-nursing" <?php echo $courseFilter === 'bsc-nursing' ? 'selected' : ''; ?>>BSC Nursing</option>
                        <option value="bmlt" <?php echo $courseFilter === 'bmlt' ? 'selected' : ''; ?>>BMLT</option>
                        <option value="pharmacy" <?php echo $courseFilter === 'pharmacy' ? 'selected' : ''; ?>>Pharmacy</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="year">Filter by Year</label>
                    <select id="year" name="year">
                        <option value="">All Years</option>
                        <?php foreach ($years as $year): ?>
                            <option value="<?php echo $year; ?>" <?php echo $yearFilter == $year ? 'selected' : ''; ?>><?php echo $year; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="display: flex; align-items: end; gap: 10px;">
                    <button type="submit" class="btn">
                        <i class="fas fa-search"></i> Search
                    </button>
                    <a href="manage_pyq.php" class="btn" style="background: #95a5a6;">
                        <i class="fas fa-times"></i> Clear
                    </a>
                </div>
            </form>

            <?php if (!empty($pyqs)): ?>
                <div style="overflow-x: auto;">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Course</th>
                                <th>Subject</th>
                                <th>Semester</th>
                                <th>Year</th>
                                <th>Upload Date</th>
                                <th>File</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pyqs as $pyq): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($pyq['title']); ?></td>
                                    <td><?php echo strtoupper($pyq['course']); ?></td>
                                    <td><?php echo htmlspecialchars($pyq['subject']); ?></td>
                                    <td><?php echo $pyq['semester']; ?></td>
                                    <td><?php echo $pyq['year']; ?></td>
                                    <td><?php echo date('M d, Y', strtotime($pyq['created_at'])); ?></td>
                                    <td>
                                        <a href="../uploads/<?php echo $pyq['file_path']; ?>" target="_blank" class="btn" style="padding: 5px 10px; font-size: 0.8rem;">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                    </td>
                                    <td>
                                        <a href="edit_pyq.php?id=<?php echo $pyq['id']; ?>" class="btn" style="padding: 5px 10px; font-size: 0.8rem; margin-right: 5px;">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <a href="delete_pyq.php?id=<?php echo $pyq['id']; ?>" class="btn btn-danger" style="padding: 5px 10px; font-size: 0.8rem;" onclick="return confirm('Are you sure you want to delete this PYQ?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>No PYQs found matching your criteria. <a href="add_pyq.php">Add the first one!</a></p>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
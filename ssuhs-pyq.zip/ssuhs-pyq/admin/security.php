<?php
// Security configuration file for admin panel
session_start();

// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Session security settings
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0); // Set to 1 when using HTTPS
ini_set('session.use_strict_mode', 1);

// Rate limiting function
function checkRateLimit($identifier, $maxAttempts = 5, $timeWindow = 300) {
    $cacheFile = sys_get_temp_dir() . '/rate_limit_' . md5($identifier);
    
    if (!file_exists($cacheFile)) {
        file_put_contents($cacheFile, json_encode(['attempts' => 0, 'first_attempt' => time()]));
        return true;
    }
    
    $data = json_decode(file_get_contents($cacheFile), true);
    $currentTime = time();
    
    // Reset if time window has passed
    if ($currentTime - $data['first_attempt'] > $timeWindow) {
        $data = ['attempts' => 0, 'first_attempt' => $currentTime];
    }
    
    // Check if limit exceeded
    if ($data['attempts'] >= $maxAttempts) {
        return false;
    }
    
    // Increment attempts
    $data['attempts']++;
    file_put_contents($cacheFile, json_encode($data));
    
    return true;
}

// CSRF token generation
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// CSRF token validation
function validateCSRFToken($token) {
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        return false;
    }
    return true;
}

// Input sanitization
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// File upload security
function validateFileUpload($file, $allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'], $maxSize = 10485760) {
    // Check if file was uploaded
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['valid' => false, 'error' => 'File upload error'];
    }
    
    // Check file size
    if ($file['size'] > $maxSize) {
        return ['valid' => false, 'error' => 'File size exceeds limit'];
    }
    
    // Check file type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $detectedType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($detectedType, $allowedTypes)) {
        return ['valid' => false, 'error' => 'Invalid file type'];
    }
    
    // Check file extension
    $allowedExtensions = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($extension, $allowedExtensions)) {
        return ['valid' => false, 'error' => 'Invalid file extension'];
    }
    
    return ['valid' => true];
}

// Secure file naming
function generateSecureFileName($originalName, $prefix = '') {
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $timestamp = time();
    $random = bin2hex(random_bytes(4));
    
    return $prefix . '_' . $timestamp . '_' . $random . '.' . $extension;
}

// Session validation
function validateSession() {
    if (!isset($_SESSION['admin_id']) || !isset($_SESSION['login_time']) || !isset($_SESSION['ip_address'])) {
        return false;
    }
    
    // Check session age (max 8 hours)
    if (time() - $_SESSION['login_time'] > 28800) {
        return false;
    }
    
    // Check IP address
    if ($_SESSION['ip_address'] !== $_SERVER['REMOTE_ADDR']) {
        return false;
    }
    
    return true;
}

// Log security events
function logSecurityEvent($event, $details = []) {
    $logFile = __DIR__ . '/../logs/security.log';
    $logDir = dirname($logFile);
    
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    
    $logEntry = sprintf(
        "[%s] IP: %s | Event: %s | Details: %s | User-Agent: %s\n",
        $timestamp,
        $ip,
        $event,
        json_encode($details),
        $userAgent
    );
    
    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}

// Initialize CSRF token for forms
generateCSRFToken();
?>

<?php
session_start();
require_once '../backend/config/database.php';

// Check if logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../backend/auth/login.php');
    exit;
}

$success = '';
$error = '';

if ($_POST) {
    $title = $_POST['title'] ?? '';
    $course = $_POST['course'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $semester = $_POST['semester'] ?? '';
    $year = $_POST['year'] ?? '';
    $description = $_POST['description'] ?? '';
    
    // Validate inputs
    if (empty($title) || empty($course) || empty($subject) || empty($semester) || empty($year)) {
        $error = 'Please fill in all required fields';
    } elseif (!in_array($course, ['mbbs', 'bsc-nursing', 'bmlt', 'pharmacy'])) {
        $error = 'Invalid course selected';
    } elseif (!is_numeric($year) || $year < 2000 || $year > date('Y')) {
        $error = 'Please enter a valid year';
    } elseif (!isset($_FILES['pyq_file']) || $_FILES['pyq_file']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Please select a file to upload';
    } else {
        // Handle file upload
        $uploadDir = '../uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $file = $_FILES['pyq_file'];
        $allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
        
        if (!in_array($file['type'], $allowedTypes)) {
            $error = 'Only PDF, JPG, JPEG, and PNG files are allowed';
        } elseif ($file['size'] > 10 * 1024 * 1024) { // 10MB limit
            $error = 'File size must be less than 10MB';
        } else {
            $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $fileName = $course . '_' . $subject . '_' . $year . '_' . time() . '.' . $fileExtension;
            $filePath = $uploadDir . $fileName;
            
            if (move_uploaded_file($file['tmp_name'], $filePath)) {
                try {
                    $pdo = getConnection();
                    $stmt = $pdo->prepare("INSERT INTO pyq (title, course, subject, semester, year, description, file_path, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$title, $course, $subject, $semester, $year, $description, $fileName, $_SESSION['admin_id']]);
                    
                    $success = 'PYQ uploaded successfully!';
                    
                    // Clear form data
                    $title = $course = $subject = $semester = $year = $description = '';
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                    // Delete uploaded file if database insert fails
                    if (file_exists($filePath)) {
                        unlink($filePath);
                    }
                }
            } else {
                $error = 'Failed to upload file';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add PYQ - SSUHS Admin</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="dashboard">
    <script src="../js/theme-toggle.js"></script>
    <header class="dashboard-header">
        <nav class="dashboard-nav">
            <div class="university-logo">
                <img src="../courses/Srimanta_Sankaradeva_University_of_Health_Sciences_logo.png" alt="SSUHS Logo">
                <div class="logo-text">
                    <h1 class="main-title">SSUHS PYQ Admin</h1>
                    <p class="sub-title">Srimanta Sankaradeva University of Health Sciences</p>
                </div>
            </div>
            <ul class="nav-links">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="manage_pyq.php"><i class="fas fa-file-alt"></i> Manage PYQ</a></li>
                <li><a href="add_pyq.php" class="active"><i class="fas fa-plus"></i> Add PYQ</a></li>
                <li><a href="manage_notes.php"><i class="fas fa-sticky-note"></i> Manage Notes</a></li>
                <li><a href="add_note.php"><i class="fas fa-plus"></i> Add Note</a></li>
            </ul>
            <div>
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                <a href="../backend/auth/logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </header>

    <main class="dashboard-content">
        <div class="content-section">
            <div class="section-header">
                <h2>Add New PYQ</h2>
                <a href="dashboard.php" class="btn">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>

            <?php if ($success): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="title">Title *</label>
                        <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($title ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="course">Course *</label>
                        <select id="course" name="course" required>
                            <option value="">Select Course</option>
                            <option value="mbbs" <?php echo (isset($course) && $course === 'mbbs') ? 'selected' : ''; ?>>MBBS</option>
                            <option value="bsc-nursing" <?php echo (isset($course) && $course === 'bsc-nursing') ? 'selected' : ''; ?>>BSC Nursing</option>
                            <option value="bmlt" <?php echo (isset($course) && $course === 'bmlt') ? 'selected' : ''; ?>>BMLT</option>
                            <option value="pharmacy" <?php echo (isset($course) && $course === 'pharmacy') ? 'selected' : ''; ?>>Pharmacy</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="subject">Subject *</label>
                        <input type="text" id="subject" name="subject" value="<?php echo htmlspecialchars($subject ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="semester">Semester *</label>
                        <select id="semester" name="semester" required>
                            <option value="">Select Semester</option>
                            <?php for($i = 1; $i <= 8; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo (isset($semester) && $semester == $i) ? 'selected' : ''; ?>>Semester <?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="year">Year *</label>
                        <input type="number" id="year" name="year" min="2000" max="<?php echo date('Y'); ?>" value="<?php echo htmlspecialchars($year ?? ''); ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" placeholder="Optional description about the question paper"><?php echo htmlspecialchars($description ?? ''); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="pyq_file">Upload File * (PDF, JPG, JPEG, PNG - Max 10MB)</label>
                    <input type="file" id="pyq_file" name="pyq_file" accept=".pdf,.jpg,.jpeg,.png" required>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-upload"></i> Upload PYQ
                    </button>
                </div>
            </form>
        </div>
    </main>
</body>
</html>
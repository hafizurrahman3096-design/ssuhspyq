<?php
session_start();
require_once '../backend/config/database.php';

// Check if logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../backend/auth/login.php');
    exit;
}

$success = '';
$error = '';

// Get Note ID from URL
$id = $_GET['id'] ?? '';
if (empty($id) || !is_numeric($id)) {
    header('Location: manage_notes.php');
    exit;
}

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = getConnection();
        
        // Get note details before deletion
        $stmt = $pdo->prepare("SELECT * FROM notes WHERE id = ?");
        $stmt->execute([$id]);
        $note = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$note) {
            $error = "Note not found";
        } else {
            // Delete file if exists
            if ($note['file_path']) {
                $filePath = '../uploads/' . $note['file_path'];
                if (file_exists($filePath)) {
                    unlink($filePath);
                }
            }
            
            // Delete from database
            $stmt = $pdo->prepare("DELETE FROM notes WHERE id = ?");
            $stmt->execute([$id]);
            
            $success = "Note deleted successfully!";
            
            // Redirect after successful deletion
            header('Location: manage_notes.php?success=' . urlencode($success));
            exit;
        }
    } catch (Exception $e) {
        $error = "Error deleting note: " . $e->getMessage();
    }
} else {
    // Fetch note details for confirmation
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("SELECT * FROM notes WHERE id = ?");
        $stmt->execute([$id]);
        $note = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$note) {
            $error = "Note not found";
        }
    } catch (Exception $e) {
        $error = "Error fetching note: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Note - SSUHS Admin</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="dashboard">
    <header class="dashboard-header">
        <nav class="dashboard-nav">
            <h1>SSUHS PYQ Admin Panel</h1>
            <ul class="nav-links">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="manage_pyq.php"><i class="fas fa-file-alt"></i> Manage PYQ</a></li>
                <li><a href="add_pyq.php"><i class="fas fa-plus"></i> Add PYQ</a></li>
                <li><a href="manage_notes.php"><i class="fas fa-sticky-note"></i> Manage Notes</a></li>
                <li><a href="add_note.php"><i class="fas fa-plus"></i> Add Note</a></li>
            </ul>
            <div>
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                <a href="../backend/auth/logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </header>

    <main class="dashboard-content">
        <div class="content-section">
            <div class="section-header">
                <h2>Delete Note</h2>
                <a href="manage_notes.php" class="btn">
                    <i class="fas fa-arrow-left"></i> Back to Manage Notes
                </a>
            </div>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
                <p><a href="manage_notes.php">Return to manage notes</a></p>
            <?php elseif ($note): ?>
                <div class="confirmation-box" style="background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 8px; padding: 2rem; margin: 2rem 0;">
                    <h3 style="color: #856404; margin-bottom: 1rem;">
                        <i class="fas fa-exclamation-triangle"></i> Confirm Deletion
                    </h3>
                    <p style="color: #856404; margin-bottom: 1.5rem;">
                        Are you sure you want to delete this note? This action cannot be undone.
                    </p>
                    
                    <div style="background: white; padding: 1rem; border-radius: 5px; margin-bottom: 1.5rem;">
                        <h4><?php echo htmlspecialchars($note['title']); ?></h4>
                        <p><strong>Course:</strong> <?php echo strtoupper($note['course']); ?></p>
                        <p><strong>Subject:</strong> <?php echo htmlspecialchars($note['subject']); ?></p>
                        <p><strong>Semester:</strong> <?php echo $note['semester']; ?></p>
                        <p><strong>Type:</strong> <?php echo ucfirst($note['note_type']); ?></p>
                        <?php if ($note['description']): ?>
                            <p><strong>Description:</strong> <?php echo htmlspecialchars($note['description']); ?></p>
                        <?php endif; ?>
                        <?php if ($note['file_path']): ?>
                            <p><strong>File:</strong> <?php echo htmlspecialchars(basename($note['file_path'])); ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <form method="POST" style="display: inline;">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Yes, Delete Note
                        </button>
                    </form>
                    <a href="manage_notes.php" class="btn" style="margin-left: 10px;">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>

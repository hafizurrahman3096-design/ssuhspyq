<?php
session_start();
require_once '../backend/config/database.php';

// Check if logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../backend/auth/login.php');
    exit;
}

$success = '';
$error = '';
$pyq = null;

// Get PYQ ID from URL
$id = $_GET['id'] ?? '';
if (empty($id) || !is_numeric($id)) {
    header('Location: manage_pyq.php');
    exit;
}

// Fetch existing PYQ data
try {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT * FROM pyq WHERE id = ?");
    $stmt->execute([$id]);
    $pyq = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$pyq) {
        $error = "PYQ not found";
    }
} catch (Exception $e) {
    $error = "Error fetching PYQ: " . $e->getMessage();
}

// Handle form submission
if ($_POST && $pyq) {
    $title = $_POST['title'] ?? '';
    $course = $_POST['course'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $semester = $_POST['semester'] ?? '';
    $year = $_POST['year'] ?? '';
    $description = $_POST['description'] ?? '';
    
    // Validate inputs
    if (empty($title) || empty($course) || empty($subject) || empty($semester) || empty($year)) {
        $error = 'Please fill in all required fields';
    } elseif (!in_array($course, ['mbbs', 'bsc-nursing', 'bmlt', 'pharmacy'])) {
        $error = 'Invalid course selected';
    } elseif (!is_numeric($year) || $year < 2000 || $year > date('Y')) {
        $error = 'Please enter a valid year';
    } else {
        try {
            $pdo = getConnection();
            
            // Handle file upload if new file is provided
            $filePath = $pyq['file_path']; // Keep existing file by default
            
            if (isset($_FILES['pyq_file']) && $_FILES['pyq_file']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['pyq_file'];
                $allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
                
                if (!in_array($file['type'], $allowedTypes)) {
                    $error = 'Only PDF, JPG, JPEG, and PNG files are allowed';
                } elseif ($file['size'] > 10 * 1024 * 1024) { // 10MB limit
                    $error = 'File size must be less than 10MB';
                } else {
                    $uploadDir = '../uploads/';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0755, true);
                    }
                    
                    // Delete old file
                    $oldFilePath = $uploadDir . $pyq['file_path'];
                    if (file_exists($oldFilePath)) {
                        unlink($oldFilePath);
                    }
                    
                    // Upload new file
                    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $fileName = $course . '_' . $subject . '_' . $year . '_' . time() . '.' . $fileExtension;
                    $newFilePath = $uploadDir . $fileName;
                    
                    if (move_uploaded_file($file['tmp_name'], $newFilePath)) {
                        $filePath = $fileName;
                    } else {
                        $error = 'Failed to upload new file';
                    }
                }
            }
            
            if (empty($error)) {
                $stmt = $pdo->prepare("UPDATE pyq SET title = ?, course = ?, subject = ?, semester = ?, year = ?, description = ?, file_path = ? WHERE id = ?");
                $stmt->execute([$title, $course, $subject, $semester, $year, $description, $filePath, $id]);
                
                // Refresh PYQ data
                $stmt = $pdo->prepare("SELECT * FROM pyq WHERE id = ?");
                $stmt->execute([$id]);
                $pyq = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $success = 'PYQ updated successfully!';
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit PYQ - SSUHS Admin</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="dashboard">
    <header class="dashboard-header">
        <nav class="dashboard-nav">
            <h1>SSUHS PYQ Admin Panel</h1>
            <ul class="nav-links">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="manage_pyq.php"><i class="fas fa-file-alt"></i> Manage PYQ</a></li>
                <li><a href="add_pyq.php"><i class="fas fa-plus"></i> Add PYQ</a></li>
                <li><a href="manage_notes.php"><i class="fas fa-sticky-note"></i> Manage Notes</a></li>
                <li><a href="add_note.php"><i class="fas fa-plus"></i> Add Note</a></li>
            </ul>
            <div>
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </header>

    <main class="dashboard-content">
        <div class="content-section">
            <div class="section-header">
                <h2>Edit PYQ</h2>
                <a href="manage_pyq.php" class="btn">
                    <i class="fas fa-arrow-left"></i> Back to Manage
                </a>
            </div>

            <?php if ($success): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($pyq): ?>
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="title">Title *</label>
                            <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($pyq['title']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="course">Course *</label>
                            <select id="course" name="course" required>
                                <option value="">Select Course</option>
                                <option value="mbbs" <?php echo $pyq['course'] === 'mbbs' ? 'selected' : ''; ?>>MBBS</option>
                                <option value="bsc-nursing" <?php echo $pyq['course'] === 'bsc-nursing' ? 'selected' : ''; ?>>BSC Nursing</option>
                                <option value="bmlt" <?php echo $pyq['course'] === 'bmlt' ? 'selected' : ''; ?>>BMLT</option>
                                <option value="pharmacy" <?php echo $pyq['course'] === 'pharmacy' ? 'selected' : ''; ?>>Pharmacy</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="subject">Subject *</label>
                            <input type="text" id="subject" name="subject" value="<?php echo htmlspecialchars($pyq['subject']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="semester">Semester *</label>
                            <select id="semester" name="semester" required>
                                <option value="">Select Semester</option>
                                <?php for($i = 1; $i <= 8; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo $pyq['semester'] == $i ? 'selected' : ''; ?>>Semester <?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="year">Year *</label>
                            <input type="number" id="year" name="year" min="2000" max="<?php echo date('Y'); ?>" value="<?php echo htmlspecialchars($pyq['year']); ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" placeholder="Optional description about the question paper"><?php echo htmlspecialchars($pyq['description'] ?? ''); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="pyq_file">Upload New File (Optional - PDF, JPG, JPEG, PNG - Max 10MB)</label>
                        <input type="file" id="pyq_file" name="pyq_file" accept=".pdf,.jpg,.jpeg,.png">
                        <?php if ($pyq['file_path']): ?>
                            <p style="margin-top: 10px; font-size: 0.9rem; color: #666;">
                                Current file: <a href="../uploads/<?php echo $pyq['file_path']; ?>" target="_blank" style="color: #3498db;">
                                    <i class="fas fa-eye"></i> View <?php echo htmlspecialchars($pyq['file_path']); ?>
                                </a>
                            </p>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Update PYQ
                    </button>
                </form>
            <?php else: ?>
                <p>PYQ not found or an error occurred. <a href="manage_pyq.php">Return to manage PYQs</a></p>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>

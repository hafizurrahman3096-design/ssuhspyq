<?php
session_start();
require_once '../backend/config/database.php';

// Check if logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../backend/auth/login.php');
    exit;
}

$success = '';
$error = '';
$note = null;

// Get Note ID from URL
$id = $_GET['id'] ?? '';
if (empty($id) || !is_numeric($id)) {
    header('Location: manage_notes.php');
    exit;
}

// Fetch existing note data
try {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT * FROM notes WHERE id = ?");
    $stmt->execute([$id]);
    $note = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$note) {
        $error = "Note not found";
    }
} catch (Exception $e) {
    $error = "Error fetching note: " . $e->getMessage();
}

// Handle form submission
if ($_POST && $note) {
    $title = $_POST['title'] ?? '';
    $course = $_POST['course'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $semester = $_POST['semester'] ?? '';
    $description = $_POST['description'] ?? '';
    $content = $_POST['content'] ?? '';
    $noteType = $_POST['note_type'] ?? 'text';
    
    // Validate inputs
    if (empty($title) || empty($course) || empty($subject) || empty($semester)) {
        $error = 'Please fill in all required fields';
    } elseif (!in_array($course, ['mbbs', 'bsc-nursing', 'bmlt', 'pharmacy'])) {
        $error = 'Invalid course selected';
    } elseif (!in_array($noteType, ['text', 'file', 'mixed'])) {
        $error = 'Invalid note type selected';
    } elseif ($noteType === 'text' && empty($content)) {
        $error = 'Please enter note content for text notes';
    } else {
        try {
            $pdo = getConnection();
            
            // Handle file upload if new file is provided
            $filePath = $note['file_path']; // Keep existing file by default
            
            if (isset($_FILES['note_file']) && $_FILES['note_file']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['note_file'];
                $allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
                
                if (!in_array($file['type'], $allowedTypes)) {
                    $error = 'Only PDF, JPG, JPEG, PNG, DOC, and DOCX files are allowed';
                } elseif ($file['size'] > 15 * 1024 * 1024) { // 15MB limit
                    $error = 'File size must be less than 15MB';
                } else {
                    $uploadDir = '../uploads/notes/';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0755, true);
                    }
                    
                    // Delete old file
                    if ($note['file_path']) {
                        $oldFilePath = '../uploads/' . $note['file_path'];
                        if (file_exists($oldFilePath)) {
                            unlink($oldFilePath);
                        }
                    }
                    
                    // Upload new file
                    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $fileName = $course . '_notes_' . $subject . '_' . time() . '.' . $fileExtension;
                    $newFilePath = $uploadDir . $fileName;
                    
                    if (move_uploaded_file($file['tmp_name'], $newFilePath)) {
                        $filePath = 'notes/' . $fileName;
                    } else {
                        $error = 'Failed to upload new file';
                    }
                }
            }
            
            if (empty($error)) {
                $stmt = $pdo->prepare("UPDATE notes SET title = ?, course = ?, subject = ?, semester = ?, description = ?, content = ?, file_path = ?, note_type = ? WHERE id = ?");
                $stmt->execute([$title, $course, $subject, $semester, $description, $content, $filePath, $noteType, $id]);
                
                // Refresh note data
                $stmt = $pdo->prepare("SELECT * FROM notes WHERE id = ?");
                $stmt->execute([$id]);
                $note = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $success = 'Note updated successfully!';
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Note - SSUHS Admin</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .note-type-section {
            display: none;
            margin-top: 1rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 5px;
            border: 1px solid #dee2e6;
        }
        .note-type-section.active {
            display: block;
        }
        textarea {
            min-height: 200px;
            resize: vertical;
        }
    </style>
</head>
<body class="dashboard">
    <header class="dashboard-header">
        <nav class="dashboard-nav">
            <h1>SSUHS PYQ Admin Panel</h1>
            <ul class="nav-links">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="manage_pyq.php"><i class="fas fa-file-alt"></i> Manage PYQ</a></li>
                <li><a href="add_pyq.php"><i class="fas fa-plus"></i> Add PYQ</a></li>
                <li><a href="manage_notes.php"><i class="fas fa-sticky-note"></i> Manage Notes</a></li>
                <li><a href="add_note.php"><i class="fas fa-plus"></i> Add Note</a></li>
            </ul>
            <div>
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                <a href="../backend/auth/logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </header>

    <main class="dashboard-content">
        <div class="content-section">
            <div class="section-header">
                <h2>Edit Note</h2>
                <a href="manage_notes.php" class="btn">
                    <i class="fas fa-arrow-left"></i> Back to Manage Notes
                </a>
            </div>

            <?php if ($success): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($note): ?>
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="title">Title *</label>
                            <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($note['title']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="course">Course *</label>
                            <select id="course" name="course" required>
                                <option value="">Select Course</option>
                                <option value="mbbs" <?php echo $note['course'] === 'mbbs' ? 'selected' : ''; ?>>MBBS</option>
                                <option value="bsc-nursing" <?php echo $note['course'] === 'bsc-nursing' ? 'selected' : ''; ?>>BSC Nursing</option>
                                <option value="bmlt" <?php echo $note['course'] === 'bmlt' ? 'selected' : ''; ?>>BMLT</option>
                                <option value="pharmacy" <?php echo $note['course'] === 'pharmacy' ? 'selected' : ''; ?>>Pharmacy</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="subject">Subject *</label>
                            <input type="text" id="subject" name="subject" value="<?php echo htmlspecialchars($note['subject']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="semester">Semester *</label>
                            <select id="semester" name="semester" required>
                                <option value="">Select Semester</option>
                                <?php for($i = 1; $i <= 8; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo $note['semester'] == $i ? 'selected' : ''; ?>>Semester <?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" placeholder="Optional description about the note"><?php echo htmlspecialchars($note['description'] ?? ''); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="note_type">Note Type *</label>
                        <select id="note_type" name="note_type" required onchange="toggleNoteType()">
                            <option value="text" <?php echo $note['note_type'] === 'text' ? 'selected' : ''; ?>>Text Only</option>
                            <option value="file" <?php echo $note['note_type'] === 'file' ? 'selected' : ''; ?>>File Only</option>
                            <option value="mixed" <?php echo $note['note_type'] === 'mixed' ? 'selected' : ''; ?>>Text + File</option>
                        </select>
                    </div>

                    <!-- Text Content Section -->
                    <div id="text_section" class="note-type-section <?php echo ($note['note_type'] === 'text' || $note['note_type'] === 'mixed') ? 'active' : ''; ?>">
                        <div class="form-group">
                            <label for="content">Note Content <?php echo $note['note_type'] === 'mixed' ? '(Optional)' : '*'; ?></label>
                            <textarea id="content" name="content" placeholder="Enter your note content here..." <?php echo $note['note_type'] === 'text' ? 'required' : ''; ?>><?php echo htmlspecialchars($note['content'] ?? ''); ?></textarea>
                        </div>
                    </div>

                    <!-- File Upload Section -->
                    <div id="file_section" class="note-type-section <?php echo ($note['note_type'] === 'file' || $note['note_type'] === 'mixed') ? 'active' : ''; ?>">
                        <div class="form-group">
                            <label for="note_file">Upload New File (Optional - PDF, JPG, JPEG, PNG, DOC, DOCX - Max 15MB)</label>
                            <input type="file" id="note_file" name="note_file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                            <?php if ($note['file_path']): ?>
                                <p style="margin-top: 10px; font-size: 0.9rem; color: #666;">
                                    Current file: <a href="../uploads/<?php echo $note['file_path']; ?>" target="_blank" style="color: #3498db;">
                                        <i class="fas fa-eye"></i> View <?php echo htmlspecialchars(basename($note['file_path'])); ?>
                                    </a>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Update Note
                    </button>
                </form>
            <?php else: ?>
                <p>Note not found or an error occurred. <a href="manage_notes.php">Return to manage notes</a></p>
            <?php endif; ?>
        </div>
    </main>

    <script>
        function toggleNoteType() {
            const noteType = document.getElementById('note_type').value;
            const textSection = document.getElementById('text_section');
            const fileSection = document.getElementById('file_section');
            const contentField = document.getElementById('content');
            const fileField = document.getElementById('note_file');
            
            // Hide all sections first
            textSection.classList.remove('active');
            fileSection.classList.remove('active');
            
            // Remove required attributes
            contentField.removeAttribute('required');
            fileField.removeAttribute('required');
            
            // Show relevant sections and set required attributes
            if (noteType === 'text') {
                textSection.classList.add('active');
                contentField.setAttribute('required', 'required');
            } else if (noteType === 'file') {
                fileSection.classList.add('active');
            } else if (noteType === 'mixed') {
                textSection.classList.add('active');
                fileSection.classList.add('active');
            }
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            toggleNoteType();
        });
    </script>
</body>
</html>

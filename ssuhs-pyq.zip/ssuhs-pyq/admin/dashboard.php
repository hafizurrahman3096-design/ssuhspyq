<?php
session_start();
require_once '../backend/config/database.php';

// Check if logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../backend/auth/login.php');
    exit;
}

// Get statistics
try {
    $pdo = getConnection();
    
    $mbbsCount = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'mbbs'")->fetchColumn();
    $nursingCount = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'bsc-nursing'")->fetchColumn();
    $bmltCount = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'bmlt'")->fetchColumn();
    $pharmacyCount = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'pharmacy'")->fetchColumn();
    $totalCount = $mbbsCount + $nursingCount + $bmltCount + $pharmacyCount;
    
    // Get recent PYQs with semester info
    $recentPYQs = $pdo->query("SELECT * FROM pyq ORDER BY created_at DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Error loading dashboard: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SSUHS PYQ</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="dashboard">
    <script src="../js/theme-toggle.js"></script>
    <header class="dashboard-header">
        <nav class="dashboard-nav">
            <div class="university-logo">
                <img src="../courses/Srimanta_Sankaradeva_University_of_Health_Sciences_logo.png" alt="SSUHS Logo">
                <div class="logo-text">
                    <h1 class="main-title">SSUHS PYQ Admin</h1>
                    <p class="sub-title">Srimanta Sankaradeva University of Health Sciences</p>
                </div>
            </div>
            <ul class="nav-links">
                <li><a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="manage_pyq.php"><i class="fas fa-file-alt"></i> Manage PYQ</a></li>
                <li><a href="add_pyq.php"><i class="fas fa-plus"></i> Add PYQ</a></li>
                <li><a href="manage_notes.php"><i class="fas fa-sticky-note"></i> Manage Notes</a></li>
                <li><a href="add_note.php"><i class="fas fa-plus"></i> Add Note</a></li>
            </ul>
            <div>
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                <a href="../backend/auth/logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </header>

    <main class="dashboard-content">
        <?php if (isset($error)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card mbbs">
                <i class="fas fa-user-md"></i>
                <h3><?php echo $mbbsCount; ?></h3>
                <p>MBBS Questions</p>
            </div>
            <div class="stat-card nursing">
                <i class="fas fa-heartbeat"></i>
                <h3><?php echo $nursingCount; ?></h3>
                <p>BSC Nursing Questions</p>
            </div>
            <div class="stat-card bmlt">
                <i class="fas fa-microscope"></i>
                <h3><?php echo $bmltCount; ?></h3>
                <p>BMLT Questions</p>
            </div>
            <div class="stat-card pharmacy">
                <i class="fas fa-pills"></i>
                <h3><?php echo $pharmacyCount; ?></h3>
                <p>Pharmacy Questions</p>
            </div>
            <div class="stat-card">
                <i class="fas fa-chart-bar"></i>
                <h3><?php echo $totalCount; ?></h3>
                <p>Total Questions</p>
            </div>
        </div>

        <div class="content-section">
            <div class="section-header">
                <h2>Recent PYQ Uploads</h2>
                <a href="add_pyq.php" class="btn btn-success">
                    <i class="fas fa-plus"></i> Add New PYQ
                </a>
            </div>

            <?php if (!empty($recentPYQs)): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Course</th>
                            <th>Subject</th>
                            <th>Semester</th>
                            <th>Year</th>
                            <th>Upload Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentPYQs as $pyq): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($pyq['title']); ?></td>
                                <td><?php echo strtoupper($pyq['course']); ?></td>
                                <td><?php echo htmlspecialchars($pyq['subject']); ?></td>
                                <td><?php echo $pyq['semester']; ?></td>
                                <td><?php echo $pyq['year']; ?></td>
                                <td><?php echo date('M d, Y', strtotime($pyq['created_at'])); ?></td>
                                <td>
                                    <a href="edit_pyq.php?id=<?php echo $pyq['id']; ?>" class="btn" style="padding: 5px 10px; font-size: 0.8rem;">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="delete_pyq.php?id=<?php echo $pyq['id']; ?>" class="btn btn-danger" style="padding: 5px 10px; font-size: 0.8rem;" onclick="return confirm('Are you sure you want to delete this PYQ?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No PYQs uploaded yet. <a href="add_pyq.php">Add the first one!</a></p>
            <?php endif; ?>
        </div>

        <div class="content-section">
            <h2>Quick Actions</h2>
            <div class="stats-grid">
                <a href="add_pyq.php" class="stat-card" style="text-decoration: none; color: inherit;">
                    <i class="fas fa-plus" style="color: #27ae60;"></i>
                    <h3>Add PYQ</h3>
                    <p>Upload new question paper</p>
                </a>
                <a href="manage_pyq.php" class="stat-card" style="text-decoration: none; color: inherit;">
                    <i class="fas fa-cogs" style="color: #3498db;"></i>
                    <h3>Manage</h3>
                    <p>Edit or delete existing PYQs</p>
                </a>
                <a href="../index.html" class="stat-card" style="text-decoration: none; color: inherit;">
                    <i class="fas fa-globe" style="color: #f39c12;"></i>
                    <h3>View Site</h3>
                    <p>Visit public website</p>
                </a>
            </div>
        </div>
    </main>
</body>
</html>
<?php
session_start();
require_once '../backend/config/database.php';

// Check if logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../backend/auth/login.php');
    exit;
}

$id = $_GET['id'] ?? '';

if (empty($id) || !is_numeric($id)) {
    header('Location: manage_pyq.php?error=Invalid PYQ ID');
    exit;
}

try {
    $pdo = getConnection();
    
    // Get file path before deleting
    $stmt = $pdo->prepare("SELECT file_path FROM pyq WHERE id = ?");
    $stmt->execute([$id]);
    $pyq = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$pyq) {
        header('Location: manage_pyq.php?error=PYQ not found');
        exit;
    }
    
    // Delete from database
    $deleteStmt = $pdo->prepare("DELETE FROM pyq WHERE id = ?");
    $deleteStmt->execute([$id]);
    
    // Delete file from uploads folder
    $filePath = '../uploads/' . $pyq['file_path'];
    if (file_exists($filePath)) {
        unlink($filePath);
    }
    
    header('Location: manage_pyq.php?success=PYQ deleted successfully');
    exit;
    
} catch (Exception $e) {
    header('Location: manage_pyq.php?error=' . urlencode('Error deleting PYQ: ' . $e->getMessage()));
    exit;
}
?>
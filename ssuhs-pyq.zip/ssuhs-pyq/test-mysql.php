<?php
// Check if MySQL PDO driver is available
if (extension_loaded('pdo_mysql')) {
    echo "MySQL PDO driver is loaded.\n";
} else {
    echo "MySQL PDO driver is NOT loaded.\n";
    echo "Please enable the MySQL PDO extension in php.ini\n";
}

// Check available PDO drivers
echo "Available PDO drivers: " . implode(', ', PDO::getAvailableDrivers()) . "\n";

// Try basic MySQL connection
try {
    $pdo = new PDO("mysql:host=localhost", 'root', '');
    echo "MySQL connection: SUCCESS\n";
    
    // Create database if not exists
    $pdo->exec("CREATE DATABASE IF NOT EXISTS ssuhs_pyq");
    echo "Database 'ssuhs_pyq' created/verified\n";
    
    // Create admin table
    $pdo->exec("USE ssuhs_pyq");
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin (
        id int(11) NOT NULL AUTO_INCREMENT,
        username varchar(50) NOT NULL,
        password varchar(255) NOT NULL,
        email varchar(100) DEFAULT NULL,
        created_at timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (id),
        UNIQUE KEY username (username)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    echo "Admin table created/verified\n";
    
    // Create admin user
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM admin WHERE username = ?");
    $stmt->execute(['admin']);
    $count = $stmt->fetchColumn();
    
    if ($count == 0) {
        $hash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO admin (username, password, email, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute(['admin', $hash, 'admin@ssuhs.edu']);
        echo "Admin user created successfully!\n";
    } else {
        echo "Admin user already exists\n";
    }
    
    echo "\n=== LOGIN CREDENTIALS ===\n";
    echo "Username: admin\n";
    echo "Password: admin123\n";
    echo "========================\n";
    
} catch (PDOException $e) {
    echo "MySQL connection failed: " . $e->getMessage() . "\n";
    echo "Please check:\n";
    echo "1. XAMPP MySQL service is running\n";
    echo "2. MySQL PDO extension is enabled in php.ini\n";
    echo "3. Database credentials are correct\n";
}
?>

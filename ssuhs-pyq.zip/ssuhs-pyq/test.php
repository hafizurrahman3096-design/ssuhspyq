<?php
// Simple test to check if PHP is working
echo "<!DOCTYPE html>
<html>
<head>
    <title>PHP Test</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        .success { color: #27ae60; background: #d5f4e6; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>";

echo "<h1>🔍 PHP Test</h1>";

// Test PHP version
echo "<div class='success'>✅ PHP Version: " . phpversion() . "</div>";

// Test MySQL extension
if (extension_loaded('pdo_mysql')) {
    echo "<div class='success'>✅ PDO MySQL extension loaded</div>";
} else {
    echo "<div class='error'>❌ PDO MySQL extension NOT loaded</div>";
}

// Test basic MySQL connection
try {
    $pdo = new PDO('mysql:host=localhost', 'root', '');
    echo "<div class='success'>✅ MySQL connection successful</div>";
} catch (Exception $e) {
    echo "<div class='error'>❌ MySQL connection failed: " . $e->getMessage() . "</div>";
}

// Test file operations
if (is_writable('.')) {
    echo "<div class='success'>✅ Directory is writable</div>";
} else {
    echo "<div class='error'>❌ Directory is not writable</div>";
}

echo "<p><a href='simple-setup.php'>Continue to Simple Setup</a></p>";
echo "</body></html>";
?>
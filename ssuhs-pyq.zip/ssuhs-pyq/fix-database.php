<?php
// Database Fix Script - Adds missing semester column and updates structure
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'ssuhs_pyq';

echo "<!DOCTYPE html>
<html>
<head>
    <title>SSUHS PYQ Database Fix</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .success { color: #27ae60; background: #d5f4e6; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: #3498db; background: #ebf3fd; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .warning { color: #f39c12; background: #fef9e7; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .step { background: #f8f9fa; padding: 15px; border-left: 4px solid #3498db; margin: 15px 0; }
        h1 { color: #2c3e50; }
        h2 { color: #34495e; }
    </style>
</head>
<body>";

echo "<h1>🔧 SSUHS PYQ Database Fix</h1>";

try {
    // Connect to database
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<div class='success'>✅ Connected to database '$database'</div>";
    
    echo "<div class='step'><h2>Step 1: Checking Current Table Structure</h2>";
    
    // Check if pyq table exists
    $tables = $pdo->query("SHOW TABLES LIKE 'pyq'")->fetchAll();
    if (empty($tables)) {
        echo "<div class='error'>❌ PYQ table doesn't exist. Creating new table...</div>";
        
        // Create new table with correct structure
        $createTable = "CREATE TABLE pyq (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            course ENUM('mbbs', 'bsc-nursing', 'bmlt', 'pharmacy') NOT NULL,
            subject VARCHAR(100) NOT NULL,
            semester INT NOT NULL DEFAULT 1,
            year INT NOT NULL,
            description TEXT,
            file_path VARCHAR(255) NOT NULL,
            uploaded_by INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (uploaded_by) REFERENCES admin(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        $pdo->exec($createTable);
        echo "<div class='success'>✅ PYQ table created with semester column</div>";
        
    } else {
        echo "<div class='success'>✅ PYQ table exists</div>";
        
        // Check current columns
        $columns = $pdo->query("SHOW COLUMNS FROM pyq")->fetchAll(PDO::FETCH_ASSOC);
        $columnNames = array_column($columns, 'Field');
        
        echo "<div class='info'>Current columns: " . implode(', ', $columnNames) . "</div>";
        
        // Check if semester column exists
        if (!in_array('semester', $columnNames)) {
            echo "<div class='warning'>⚠️ Semester column missing. Adding it...</div>";
            
            // Add semester column
            $pdo->exec("ALTER TABLE pyq ADD COLUMN semester INT NOT NULL DEFAULT 1 AFTER subject");
            echo "<div class='success'>✅ Semester column added successfully</div>";
            
            // Update existing records with default semester values
            $pdo->exec("UPDATE pyq SET semester = 1 WHERE semester IS NULL OR semester = 0");
            echo "<div class='success'>✅ Updated existing records with default semester values</div>";
            
        } else {
            echo "<div class='success'>✅ Semester column already exists</div>";
        }
        
        // Check if pharmacy is in course enum
        $courseColumn = $pdo->query("SHOW COLUMNS FROM pyq WHERE Field = 'course'")->fetch(PDO::FETCH_ASSOC);
        if ($courseColumn && strpos($courseColumn['Type'], 'pharmacy') === false) {
            echo "<div class='warning'>⚠️ Pharmacy course option missing. Adding it...</div>";
            
            // Add pharmacy to course enum
            $pdo->exec("ALTER TABLE pyq MODIFY COLUMN course ENUM('mbbs', 'bsc-nursing', 'bmlt', 'pharmacy') NOT NULL");
            echo "<div class='success'>✅ Pharmacy course option added</div>";
        } else {
            echo "<div class='success'>✅ Pharmacy course option already exists</div>";
        }
    }
    
    echo "</div><div class='step'><h2>Step 2: Verifying Admin Table</h2>";
    
    // Check admin table
    $adminTables = $pdo->query("SHOW TABLES LIKE 'admin'")->fetchAll();
    if (empty($adminTables)) {
        echo "<div class='warning'>⚠️ Admin table missing. Creating it...</div>";
        
        $createAdminTable = "CREATE TABLE admin (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        $pdo->exec($createAdminTable);
        echo "<div class='success'>✅ Admin table created</div>";
        
        // Create default admin
        $defaultPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO admin (username, password, email) VALUES (?, ?, ?)");
        $stmt->execute(['admin', $defaultPassword, 'admin@ssuhs.edu']);
        echo "<div class='success'>✅ Default admin user created</div>";
        
    } else {
        echo "<div class='success'>✅ Admin table exists</div>";
        
        // Check if admin user exists
        $adminCount = $pdo->query("SELECT COUNT(*) FROM admin WHERE username = 'admin'")->fetchColumn();
        if ($adminCount == 0) {
            echo "<div class='warning'>⚠️ Default admin user missing. Creating it...</div>";
            
            $defaultPassword = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO admin (username, password, email) VALUES (?, ?, ?)");
            $stmt->execute(['admin', $defaultPassword, 'admin@ssuhs.edu']);
            echo "<div class='success'>✅ Default admin user created</div>";
        } else {
            echo "<div class='success'>✅ Default admin user exists</div>";
        }
    }
    
    echo "</div><div class='step'><h2>Step 3: Testing Database Operations</h2>";
    
    // Test inserting a record with semester
    try {
        $testStmt = $pdo->prepare("INSERT INTO pyq (title, course, subject, semester, year, description, file_path, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $testStmt->execute([
            'Test PYQ with Semester',
            'mbbs',
            'Test Subject',
            1,
            2024,
            'Test description',
            'test_file.pdf',
            1
        ]);
        
        $testId = $pdo->lastInsertId();
        echo "<div class='success'>✅ Successfully inserted test record with semester</div>";
        
        // Clean up test record
        $pdo->prepare("DELETE FROM pyq WHERE id = ?")->execute([$testId]);
        echo "<div class='success'>✅ Test record cleaned up</div>";
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Test insert failed: " . $e->getMessage() . "</div>";
    }
    
    echo "</div><div class='step'><h2>Step 4: Final Verification</h2>";
    
    // Final verification
    $finalColumns = $pdo->query("SHOW COLUMNS FROM pyq")->fetchAll(PDO::FETCH_ASSOC);
    $finalColumnNames = array_column($finalColumns, 'Field');
    
    $requiredColumns = ['id', 'title', 'course', 'subject', 'semester', 'year', 'description', 'file_path', 'uploaded_by', 'created_at'];
    $missingColumns = array_diff($requiredColumns, $finalColumnNames);
    
    if (empty($missingColumns)) {
        echo "<div class='success'>✅ All required columns present: " . implode(', ', $finalColumnNames) . "</div>";
    } else {
        echo "<div class='error'>❌ Missing columns: " . implode(', ', $missingColumns) . "</div>";
    }
    
    // Count records
    $pyqCount = $pdo->query("SELECT COUNT(*) FROM pyq")->fetchColumn();
    $adminCount = $pdo->query("SELECT COUNT(*) FROM admin")->fetchColumn();
    
    echo "<div class='success'>✅ PYQ records: $pyqCount</div>";
    echo "<div class='success'>✅ Admin users: $adminCount</div>";
    
    echo "</div>";
    
    echo "<div class='success'>
        <h2>🎉 Database Fix Complete!</h2>
        <p>Your database has been successfully updated with the semester column and all required features.</p>
        <p><strong>You can now:</strong></p>
        <ul>
            <li><a href='index.html'>Visit the main website</a></li>
            <li><a href='admin/'>Access the admin panel</a></li>
            <li><a href='backend/auth/login.php'>Login to admin (admin/admin123)</a></li>
        </ul>
    </div>";
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database Error: " . $e->getMessage() . "</div>";
    
    if (strpos($e->getMessage(), "Unknown database") !== false) {
        echo "<div class='info'>
            <h3>Database doesn't exist. Please:</h3>
            <ol>
                <li>Run the <a href='setup-database.php'>complete database setup</a></li>
                <li>Or create the database manually in phpMyAdmin</li>
            </ol>
        </div>";
    }
} catch (Exception $e) {
    echo "<div class='error'>❌ General Error: " . $e->getMessage() . "</div>";
}

echo "</body></html>";
?>
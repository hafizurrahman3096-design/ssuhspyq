<?php
require_once 'config.php';

// Get the PYQ ID from URL
$id = $_GET['id'] ?? '';

if (empty($id) || !is_numeric($id)) {
    die('Invalid PYQ ID');
}

try {
    $pdo = connectDB();
    
    // Get PYQ details
    $stmt = $pdo->prepare("SELECT * FROM pyq WHERE id = ?");
    $stmt->execute([$id]);
    $pyq = $stmt->fetch();
    
    if (!$pyq) {
        die('PYQ not found');
    }
    
    $filePath = 'uploads/' . $pyq['file_path'];
    
    // Check if file exists
    if (!file_exists($filePath)) {
        // Create a sample PDF content for demonstration
        $sampleContent = "Sample PYQ Content for: " . $pyq['title'] . "\n\n";
        $sampleContent .= "Course: " . strtoupper($pyq['course']) . "\n";
        $sampleContent .= "Subject: " . $pyq['subject'] . "\n";
        $sampleContent .= "Semester: " . $pyq['semester'] . "\n";
        $sampleContent .= "Year: " . $pyq['year'] . "\n\n";
        $sampleContent .= "Description: " . $pyq['description'] . "\n\n";
        $sampleContent .= "This is a sample file. Please upload actual PYQ files through the admin panel.";
        
        // Create uploads directory if it doesn't exist
        if (!is_dir('uploads')) {
            mkdir('uploads', 0755, true);
        }
        
        // Create a simple text file as placeholder
        file_put_contents($filePath . '.txt', $sampleContent);
        $filePath = $filePath . '.txt';
        $fileName = $pyq['title'] . '.txt';
        $mimeType = 'text/plain';
    } else {
        $fileName = $pyq['title'] . '.pdf';
        $mimeType = 'application/pdf';
    }
    
    // Set headers for download
    header('Content-Type: ' . $mimeType);
    header('Content-Disposition: attachment; filename="' . $fileName . '"');
    header('Content-Length: ' . filesize($filePath));
    header('Cache-Control: private');
    header('Pragma: private');
    header('Expires: 0');
    
    // Output file
    readfile($filePath);
    exit;
    
} catch (Exception $e) {
    die('Error downloading file: ' . $e->getMessage());
}
?>
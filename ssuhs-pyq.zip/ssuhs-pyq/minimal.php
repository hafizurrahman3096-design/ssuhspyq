<?php
echo "PHP is working!<br>";
echo "PHP Version: " . phpversion() . "<br>";

// Test MySQL
try {
    $pdo = new PDO('mysql:host=localhost', 'root', '');
    echo "MySQL connection: OK<br>";
} catch (Exception $e) {
    echo "MySQL error: " . $e->getMessage() . "<br>";
}

echo '<a href="setup-minimal.php">Setup Database</a>';
?>
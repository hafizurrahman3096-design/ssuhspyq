-- SSUHS PYQ Database Setup
-- Import this file into phpMyAdmin or run it in MySQL

-- Create database
CREATE DATABASE IF NOT EXISTS `ssuhs_pyq` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `ssuhs_pyq`;

-- Create admin table
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create pyq table with semester support
CREATE TABLE IF NOT EXISTS `pyq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `course` enum('mbbs','bsc-nursing','bmlt','pharmacy') NOT NULL,
  `subject` varchar(100) NOT NULL,
  `semester` int(11) NOT NULL DEFAULT 1,
  `year` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_course` (`course`),
  KEY `idx_semester` (`semester`),
  KEY `idx_year` (`year`),
  KEY `idx_subject` (`subject`),
  KEY `uploaded_by` (`uploaded_by`),
  CONSTRAINT `pyq_ibfk_1` FOREIGN KEY (`uploaded_by`) REFERENCES `admin` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user (password: admin123)
INSERT INTO `admin` (`id`, `username`, `password`, `email`, `created_at`) VALUES
(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@ssuhs.edu', NOW())
ON DUPLICATE KEY UPDATE password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

-- Insert sample PYQ data
INSERT INTO `pyq` (`id`, `title`, `course`, `subject`, `semester`, `year`, `description`, `file_path`, `uploaded_by`, `created_at`) VALUES
(1, 'MBBS Anatomy 2023 - First Semester', 'mbbs', 'Anatomy', 1, 2023, 'Human anatomy question paper for first semester MBBS students', 'mbbs_anatomy_2023_sem1.pdf', 1, NOW()),
(2, 'MBBS Physiology 2023 - Second Semester', 'mbbs', 'Physiology', 2, 2023, 'Human physiology question paper for second semester', 'mbbs_physiology_2023_sem2.pdf', 1, NOW()),
(3, 'BSC Nursing Fundamentals 2023', 'bsc-nursing', 'Nursing Fundamentals', 1, 2023, 'Basic nursing fundamentals question paper', 'bsc_nursing_fundamentals_2023_sem1.pdf', 1, NOW()),
(4, 'BMLT Clinical Pathology 2023', 'bmlt', 'Clinical Pathology', 3, 2023, 'Clinical pathology question paper for third semester', 'bmlt_clinical_pathology_2023_sem3.pdf', 1, NOW()),
(5, 'Pharmacy Pharmaceutics 2023', 'pharmacy', 'Pharmaceutics', 1, 2023, 'Basic pharmaceutics question paper for pharmacy students', 'pharmacy_pharmaceutics_2023_sem1.pdf', 1, NOW()),
(6, 'MBBS Biochemistry 2022', 'mbbs', 'Biochemistry', 2, 2022, 'Biochemistry question paper for second semester', 'mbbs_biochemistry_2022_sem2.pdf', 1, NOW()),
(7, 'BSC Nursing Community Health 2022', 'bsc-nursing', 'Community Health', 4, 2022, 'Community health nursing question paper', 'bsc_nursing_community_2022_sem4.pdf', 1, NOW()),
(8, 'BMLT Microbiology 2022', 'bmlt', 'Microbiology', 2, 2022, 'Microbiology question paper for BMLT students', 'bmlt_microbiology_2022_sem2.pdf', 1, NOW())
ON DUPLICATE KEY UPDATE title = VALUES(title);

-- Create uploads directory structure (this is just for reference)
-- You need to create these folders manually:
-- uploads/
-- uploads/.htaccess

COMMIT;
<?php
// Simple database connection test
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html>
<html>
<head>
    <title>Database Connection Test</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        .success { color: #27ae60; background: #d5f4e6; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: #3498db; background: #ebf3fd; padding: 10px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>";

echo "<h1>🔍 Database Connection Test</h1>";

// Test basic MySQL connection
try {
    $pdo = new PDO('mysql:host=localhost', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<div class='success'>✅ MySQL server connection: SUCCESS</div>";
    
    // Test database existence
    $databases = $pdo->query("SHOW DATABASES LIKE 'ssuhs_pyq'")->fetchAll();
    if (count($databases) > 0) {
        echo "<div class='success'>✅ Database 'ssuhs_pyq' exists</div>";
        
        // Connect to specific database
        $pdo = new PDO('mysql:host=localhost;dbname=ssuhs_pyq', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Test tables
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        if (in_array('admin', $tables) && in_array('pyq', $tables)) {
            echo "<div class='success'>✅ Required tables exist: " . implode(', ', $tables) . "</div>";
            
            // Test admin user
            $adminCount = $pdo->query("SELECT COUNT(*) FROM admin")->fetchColumn();
            echo "<div class='success'>✅ Admin users found: $adminCount</div>";
            
            // Test PYQ records
            $pyqCount = $pdo->query("SELECT COUNT(*) FROM pyq")->fetchColumn();
            echo "<div class='success'>✅ PYQ records found: $pyqCount</div>";
            
            echo "<div class='info'>
                <h3>✅ Everything looks good!</h3>
                <p>Your database is properly set up. You can now:</p>
                <ul>
                    <li><a href='index.html'>Visit the main website</a></li>
                    <li><a href='admin/'>Access the admin panel</a></li>
                    <li><a href='backend/auth/login.php'>Login directly</a></li>
                </ul>
            </div>";
            
        } else {
            echo "<div class='error'>❌ Required tables missing. Please run the database setup.</div>";
        }
        
    } else {
        echo "<div class='error'>❌ Database 'ssuhs_pyq' does not exist</div>";
        echo "<div class='info'>Please run the <a href='setup-database.php'>database setup script</a></div>";
    }
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Connection failed: " . $e->getMessage() . "</div>";
    echo "<div class='info'>
        <h3>Possible solutions:</h3>
        <ul>
            <li>Start XAMPP/WAMP and ensure MySQL is running</li>
            <li>Check if the MySQL service is started</li>
            <li>Verify your database credentials</li>
            <li>Run the <a href='setup-database.php'>database setup script</a></li>
        </ul>
    </div>";
}

echo "</body></html>";
?>
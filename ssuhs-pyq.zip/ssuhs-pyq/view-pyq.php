<?php
// Simple public view of PYQs
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'ssuhs_pyq';

$course = $_GET['course'] ?? '';
$pyqs = [];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    if ($course) {
        $stmt = $pdo->prepare("SELECT * FROM pyq WHERE course = ? ORDER BY year DESC, semester ASC");
        $stmt->execute([$course]);
        $pyqs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $pyqs = $pdo->query("SELECT * FROM pyq ORDER BY course, year DESC, semester ASC")->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get course counts
    $courses = [
        'mbbs' => $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'mbbs'")->fetchColumn(),
        'bsc-nursing' => $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'bsc-nursing'")->fetchColumn(),
        'bmlt' => $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'bmlt'")->fetchColumn(),
        'pharmacy' => $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'pharmacy'")->fetchColumn()
    ];
    
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>SSUHS PYQ - Previous Year Questions</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f5f5f5; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px 0; text-align: center; }
        .container { max-width: 1000px; margin: 0 auto; padding: 20px; }
        .courses { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 30px 0; }
        .course-card { background: white; padding: 20px; border-radius: 10px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.1); transition: transform 0.3s; }
        .course-card:hover { transform: translateY(-5px); }
        .course-card h3 { margin: 0 0 10px 0; color: #2c3e50; }
        .course-card .count { font-size: 2em; font-weight: bold; color: #3498db; }
        .course-card a { display: inline-block; margin-top: 15px; background: #3498db; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
        .course-card a:hover { background: #2980b9; }
        .pyq-list { background: white; padding: 20px; border-radius: 10px; margin-top: 20px; }
        .pyq-item { border-bottom: 1px solid #eee; padding: 15px 0; }
        .pyq-item:last-child { border-bottom: none; }
        .pyq-title { font-weight: bold; color: #2c3e50; margin-bottom: 5px; }
        .pyq-details { color: #666; font-size: 0.9em; margin-bottom: 10px; }
        .download-btn { background: #27ae60; color: white; padding: 8px 15px; text-decoration: none; border-radius: 3px; font-size: 0.9em; }
        .download-btn:hover { background: #219a52; }
        .filter-bar { background: white; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
        .filter-bar a { display: inline-block; margin-right: 15px; padding: 8px 15px; background: #ecf0f1; color: #2c3e50; text-decoration: none; border-radius: 5px; }
        .filter-bar a.active, .filter-bar a:hover { background: #3498db; color: white; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 15px; border-radius: 5px; margin: 15px 0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🏥 SSUHS Previous Year Questions</h1>
        <p>Srimanta Sankaradeva University of Health Sciences</p>
    </div>
    
    <div class="container">
        <?php if (isset($error)): ?>
            <div class="error">❌ Error: <?php echo htmlspecialchars($error); ?></div>
            <p><a href="simple-setup.php">Run database setup</a> first.</p>
        <?php else: ?>
            
            <?php if (!$course): ?>
                <h2>📚 Available Courses</h2>
                <div class="courses">
                    <div class="course-card">
                        <h3>🩺 MBBS</h3>
                        <div class="count"><?php echo $courses['mbbs']; ?></div>
                        <p>Bachelor of Medicine and Bachelor of Surgery</p>
                        <a href="?course=mbbs">View Questions</a>
                    </div>
                    <div class="course-card">
                        <h3>❤️ BSC Nursing</h3>
                        <div class="count"><?php echo $courses['bsc-nursing']; ?></div>
                        <p>Bachelor of Science in Nursing</p>
                        <a href="?course=bsc-nursing">View Questions</a>
                    </div>
                    <div class="course-card">
                        <h3>🔬 BMLT</h3>
                        <div class="count"><?php echo $courses['bmlt']; ?></div>
                        <p>Bachelor of Medical Laboratory Technology</p>
                        <a href="?course=bmlt">View Questions</a>
                    </div>
                    <div class="course-card">
                        <h3>💊 Pharmacy</h3>
                        <div class="count"><?php echo $courses['pharmacy']; ?></div>
                        <p>Bachelor of Pharmacy</p>
                        <a href="?course=pharmacy">View Questions</a>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if ($course): ?>
                <div class="filter-bar">
                    <a href="view-pyq.php">← All Courses</a>
                    <a href="?course=mbbs" <?php echo $course == 'mbbs' ? 'class="active"' : ''; ?>>MBBS</a>
                    <a href="?course=bsc-nursing" <?php echo $course == 'bsc-nursing' ? 'class="active"' : ''; ?>>BSC Nursing</a>
                    <a href="?course=bmlt" <?php echo $course == 'bmlt' ? 'class="active"' : ''; ?>>BMLT</a>
                    <a href="?course=pharmacy" <?php echo $course == 'pharmacy' ? 'class="active"' : ''; ?>>Pharmacy</a>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($pyqs)): ?>
                <div class="pyq-list">
                    <h2>📋 <?php echo $course ? strtoupper($course) . ' ' : ''; ?>Previous Year Questions</h2>
                    <?php foreach ($pyqs as $pyq): ?>
                        <div class="pyq-item">
                            <div class="pyq-title"><?php echo htmlspecialchars($pyq['title']); ?></div>
                            <div class="pyq-details">
                                <strong>Course:</strong> <?php echo strtoupper($pyq['course']); ?> | 
                                <strong>Subject:</strong> <?php echo htmlspecialchars($pyq['subject']); ?> | 
                                <strong>Semester:</strong> <?php echo $pyq['semester']; ?> | 
                                <strong>Year:</strong> <?php echo $pyq['year']; ?>
                            </div>
                            <?php if ($pyq['description']): ?>
                                <div style="color: #666; margin-bottom: 10px;"><?php echo htmlspecialchars($pyq['description']); ?></div>
                            <?php endif; ?>
                            <a href="download-simple.php?id=<?php echo $pyq['id']; ?>" class="download-btn">
                                📥 Download
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php elseif ($course): ?>
                <div class="pyq-list">
                    <h2>No questions found for <?php echo strtoupper($course); ?></h2>
                    <p>Please check back later or contact the administrator.</p>
                </div>
            <?php endif; ?>
            
        <?php endif; ?>
        
        <div style="text-align: center; margin-top: 40px; padding: 20px; background: white; border-radius: 10px;">
            <p><a href="admin-simple.php">🔐 Admin Login</a> | <a href="simple-setup.php">🔧 Setup Database</a></p>
        </div>
    </div>
</body>
</html>
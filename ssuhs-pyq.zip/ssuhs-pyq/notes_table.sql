-- Add notes table to SSUHS PYQ database
-- Run this SQL to add notes functionality

USE `ssuhs_pyq`;

-- Create notes table
CREATE TABLE IF NOT EXISTS `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `course` enum('mbbs','bsc-nursing','bmlt','pharmacy') NOT NULL,
  `subject` varchar(100) NOT NULL,
  `semester` int(11) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `note_type` enum('text','file','mixed') NOT NULL DEFAULT 'text',
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_course` (`course`),
  KEY `idx_semester` (`semester`),
  KEY `idx_subject` (`subject`),
  KEY `idx_note_type` (`note_type`),
  KEY `uploaded_by` (`uploaded_by`),
  CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`uploaded_by`) REFERENCES `admin` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample notes data
INSERT INTO `notes` (`id`, `title`, `course`, `subject`, `semester`, `description`, `content`, `note_type`, `uploaded_by`, `created_at`) VALUES
(1, 'Anatomy Study Guide - Chapter 1', 'mbbs', 'Anatomy', 1, 'Comprehensive study guide for human anatomy basics', 'Human anatomy is the scientific study of the body\'s structures. Some of these structures are very small and can only be observed and analyzed with the assistance of a microscope, while other larger structures can readily be seen, manipulated, measured, and weighed. The word "anatomy" derives from a Greek root that means "to cut apart." Human anatomy was first studied by observing the exterior of the body and observing the wounds of soldiers and other injuries.', 'text', 1, NOW()),
(2, 'Physiology Lecture Notes', 'mbbs', 'Physiology', 2, 'Complete lecture notes covering basic physiology concepts', 'Physiology is the study of how the human body works. It describes the chemistry and physics behind basic body functions, from how molecules behave in cells to how systems of organs work together. It helps us understand what happens when a person is healthy and what happens to the body in disease.', 'text', 1, NOW()),
(3, 'Nursing Fundamentals Handbook', 'bsc-nursing', 'Nursing Fundamentals', 1, 'Essential nursing procedures and best practices', 'Nursing fundamentals encompass the basic skills and knowledge that every nurse must possess. This includes patient assessment, medication administration, infection control, and communication skills. Proper documentation and ethical practice are also essential components.', 'text', 1, NOW()),
(4, 'Clinical Pathology Reference', 'bmlt', 'Clinical Pathology', 3, 'Reference guide for clinical pathology procedures', 'Clinical pathology involves the laboratory analysis of blood, urine, and tissue samples to diagnose and treat disease. Key areas include clinical chemistry, hematology, microbiology, and transfusion medicine.', 'text', 1, NOW()),
(5, 'Pharmaceutics Formulation Notes', 'pharmacy', 'Pharmaceutics', 1, 'Notes on drug formulation and delivery systems', 'Pharmaceutics is the discipline of pharmacy that deals with the process of turning a new chemical entity (NCE) or old drugs into a medication to be used safely and effectively by patients. It includes drug design, formulation, and evaluation.', 'text', 1, NOW());

COMMIT;

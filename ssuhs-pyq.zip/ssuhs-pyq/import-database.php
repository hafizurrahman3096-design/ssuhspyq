<?php
// Database Import Script
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = 'localhost';
$username = 'root';
$password = '';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Database Import - SSUHS PYQ</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .success { color: #27ae60; background: #d5f4e6; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .info { color: #3498db; background: #ebf3fd; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .step { background: #f8f9fa; padding: 15px; border-left: 4px solid #3498db; margin: 15px 0; }
        h1 { color: #2c3e50; }
        .btn { display: inline-block; background: #3498db; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 10px 5px; }
        .btn:hover { background: #2980b9; }
        .btn-success { background: #27ae60; }
        .btn-success:hover { background: #219a52; }
    </style>
</head>
<body>";

echo "<h1>📊 SSUHS PYQ Database Import</h1>";

try {
    // Connect to MySQL server
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<div class='success'>✅ Connected to MySQL server</div>";
    
    // Read and execute SQL file
    if (file_exists('ssuhs_pyq.sql')) {
        echo "<div class='step'><h2>Importing Database...</h2>";
        
        $sql = file_get_contents('ssuhs_pyq.sql');
        
        // Split SQL into individual statements
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        
        $successCount = 0;
        foreach ($statements as $statement) {
            if (!empty($statement) && !preg_match('/^--/', $statement)) {
                try {
                    $pdo->exec($statement);
                    $successCount++;
                } catch (PDOException $e) {
                    // Ignore duplicate entry errors and other non-critical errors
                    if (strpos($e->getMessage(), 'Duplicate entry') === false && 
                        strpos($e->getMessage(), 'already exists') === false) {
                        echo "<div class='error'>⚠️ Warning: " . $e->getMessage() . "</div>";
                    }
                }
            }
        }
        
        echo "<div class='success'>✅ Executed $successCount SQL statements successfully</div>";
        
        // Verify the import
        $pdo->exec("USE ssuhs_pyq");
        
        // Check tables
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        echo "<div class='success'>✅ Tables created: " . implode(', ', $tables) . "</div>";
        
        // Check admin user
        $adminCount = $pdo->query("SELECT COUNT(*) FROM admin")->fetchColumn();
        echo "<div class='success'>✅ Admin users: $adminCount</div>";
        
        // Check PYQ records
        $pyqCount = $pdo->query("SELECT COUNT(*) FROM pyq")->fetchColumn();
        echo "<div class='success'>✅ PYQ records: $pyqCount</div>";
        
        echo "</div>";
        
        echo "<div class='success'>
            <h2>🎉 Database Import Complete!</h2>
            <p>Your database has been successfully imported with sample data.</p>
        </div>";
        
        echo "<div class='info'>
            <h3>🔑 Login Credentials:</h3>
            <p><strong>Username:</strong> admin</p>
            <p><strong>Password:</strong> admin123</p>
        </div>";
        
        echo "<div style='text-align: center; margin-top: 30px;'>
            <a href='login.php' class='btn btn-success'>🚀 Go to Admin Login</a>
            <a href='dashboard.php' class='btn'>📊 View Dashboard</a>
            <a href='index.html' class='btn'>🌐 Main Website</a>
        </div>";
        
    } else {
        echo "<div class='error'>❌ SQL file 'ssuhs_pyq.sql' not found!</div>";
        echo "<div class='info'>Please make sure the ssuhs_pyq.sql file is in the same directory as this script.</div>";
    }
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database Error: " . $e->getMessage() . "</div>";
    echo "<div class='info'>
        <h3>Common Solutions:</h3>
        <ul>
            <li>Make sure XAMPP is running</li>
            <li>Check if MySQL service is started</li>
            <li>Verify database credentials</li>
        </ul>
    </div>";
}

echo "</body></html>";
?>
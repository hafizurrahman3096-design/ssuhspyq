<?php
echo "<h1>Database Setup</h1>";

try {
    $pdo = new PDO('mysql:host=localhost', 'root', '');
    $pdo->exec("CREATE DATABASE IF NOT EXISTS ssuhs_pyq");
    $pdo->exec("USE ssuhs_pyq");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50),
        password VARCHAR(255)
    )");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS pyq (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255),
        course VARCHAR(50),
        subject VARCHAR(100),
        semester INT,
        year INT,
        description TEXT,
        file_path VARCHAR(255)
    )");
    
    // Insert admin
    $password = password_hash('admin123', PASSWORD_DEFAULT);
    $pdo->exec("INSERT IGNORE INTO admin (id, username, password) VALUES (1, 'admin', '$password')");
    
    // Insert sample data
    $pdo->exec("INSERT IGNORE INTO pyq (id, title, course, subject, semester, year, description, file_path) VALUES 
        (1, 'MBBS Anatomy 2023', 'mbbs', 'Anatomy', 1, 2023, 'Sample anatomy paper', 'anatomy.pdf'),
        (2, 'BSC Nursing 2023', 'bsc-nursing', 'Nursing', 1, 2023, 'Sample nursing paper', 'nursing.pdf'),
        (3, 'BMLT Lab 2023', 'bmlt', 'Laboratory', 2, 2023, 'Sample lab paper', 'lab.pdf'),
        (4, 'Pharmacy 2023', 'pharmacy', 'Pharmaceutics', 1, 2023, 'Sample pharmacy paper', 'pharmacy.pdf')");
    
    echo "<p style='color: green;'>Database setup complete!</p>";
    echo "<p><a href='admin-minimal.php'>Go to Admin Panel</a></p>";
    echo "<p><a href='public-minimal.php'>View Public Site</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>
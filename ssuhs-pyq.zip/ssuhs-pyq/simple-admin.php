<?php
// Simple admin panel without complex includes
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Check if logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: simple-login.php');
    exit;
}

// Simple database connection
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'ssuhs_pyq';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get statistics
    $mbbsCount = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'mbbs'")->fetchColumn();
    $nursingCount = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'bsc-nursing'")->fetchColumn();
    $bmltCount = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'bmlt'")->fetchColumn();
    $pharmacyCount = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'pharmacy'")->fetchColumn();
    $totalCount = $mbbsCount + $nursingCount + $bmltCount + $pharmacyCount;
    
    // Get recent PYQs
    $recentPYQs = $pdo->query("SELECT * FROM pyq ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Database error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Simple Admin Dashboard - SSUHS PYQ</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f8f9fa; }
        .header { background: #2c3e50; color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 5px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .stat-card h3 { margin: 0; font-size: 2rem; color: #3498db; }
        .stat-card p { margin: 5px 0 0 0; color: #666; }
        .table { width: 100%; background: white; border-radius: 5px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .table th, .table td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        .table th { background: #f8f9fa; font-weight: bold; }
        .btn { display: inline-block; background: #3498db; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px; }
        .btn:hover { background: #2980b9; }
        .btn-danger { background: #e74c3c; }
        .btn-danger:hover { background: #c0392b; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .success { color: #27ae60; background: #d5f4e6; padding: 15px; border-radius: 5px; margin: 15px 0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🏥 SSUHS PYQ Admin Dashboard</h1>
        <p>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?> | 
           <a href="simple-login.php?logout=1" style="color: #ecf0f1;">Logout</a></p>
    </div>
    
    <?php if (isset($error)): ?>
        <div class="error">❌ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <div class="stats">
        <div class="stat-card">
            <h3><?php echo $mbbsCount ?? 0; ?></h3>
            <p>MBBS Questions</p>
        </div>
        <div class="stat-card">
            <h3><?php echo $nursingCount ?? 0; ?></h3>
            <p>BSC Nursing Questions</p>
        </div>
        <div class="stat-card">
            <h3><?php echo $bmltCount ?? 0; ?></h3>
            <p>BMLT Questions</p>
        </div>
        <div class="stat-card">
            <h3><?php echo $pharmacyCount ?? 0; ?></h3>
            <p>Pharmacy Questions</p>
        </div>
        <div class="stat-card">
            <h3><?php echo $totalCount ?? 0; ?></h3>
            <p>Total Questions</p>
        </div>
    </div>
    
    <div style="background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h2>📋 Recent PYQ Uploads</h2>
        
        <?php if (!empty($recentPYQs)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Course</th>
                        <th>Subject</th>
                        <th>Semester</th>
                        <th>Year</th>
                        <th>Upload Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentPYQs as $pyq): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($pyq['title']); ?></td>
                            <td><?php echo strtoupper($pyq['course']); ?></td>
                            <td><?php echo htmlspecialchars($pyq['subject']); ?></td>
                            <td><?php echo $pyq['semester'] ?? 'N/A'; ?></td>
                            <td><?php echo $pyq['year']; ?></td>
                            <td><?php echo date('M d, Y', strtotime($pyq['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No PYQs uploaded yet.</p>
        <?php endif; ?>
    </div>
    
    <div style="margin-top: 30px; text-align: center;">
        <a href="admin/add_pyq.php" class="btn">➕ Add New PYQ</a>
        <a href="admin/manage_pyq.php" class="btn">📝 Manage PYQs</a>
        <a href="index.html" class="btn">🌐 View Website</a>
        <a href="debug.php" class="btn">🔍 Debug Info</a>
    </div>
    
    <div style="background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-top: 20px;">
        <h3>🔧 System Status</h3>
        <p><strong>Database:</strong> <?php echo isset($error) ? '❌ Error' : '✅ Connected'; ?></p>
        <p><strong>Session:</strong> ✅ Active (User ID: <?php echo $_SESSION['admin_id']; ?>)</p>
        <p><strong>PHP Version:</strong> <?php echo phpversion(); ?></p>
    </div>
</body>
</html>
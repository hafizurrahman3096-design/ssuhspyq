<?php
session_start();

// Simple login
if (isset($_POST['login'])) {
    if ($_POST['username'] == 'admin' && $_POST['password'] == 'admin123') {
        $_SESSION['admin'] = true;
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin-minimal.php');
    exit;
}

if (!isset($_SESSION['admin'])) {
    echo '<h2>Admin Login</h2>
    <form method="post">
        Username: <input type="text" name="username" value="admin"><br><br>
        Password: <input type="password" name="password" value="admin123"><br><br>
        <input type="submit" name="login" value="Login">
    </form>';
    exit;
}

// Get data
try {
    $pdo = new PDO('mysql:host=localhost;dbname=ssuhs_pyq', 'root', '');
    $pyqs = $pdo->query("SELECT * FROM pyq ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    echo "Database error: " . $e->getMessage();
    exit;
}
?>

<h1>Admin Panel</h1>
<p><a href="?logout=1">Logout</a> | <a href="public-minimal.php">View Public Site</a></p>

<h2>PYQ List</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Course</th>
        <th>Subject</th>
        <th>Semester</th>
        <th>Year</th>
        <th>Action</th>
    </tr>
    <?php foreach ($pyqs as $pyq): ?>
    <tr>
        <td><?php echo $pyq['id']; ?></td>
        <td><?php echo htmlspecialchars($pyq['title']); ?></td>
        <td><?php echo strtoupper($pyq['course']); ?></td>
        <td><?php echo htmlspecialchars($pyq['subject']); ?></td>
        <td><?php echo $pyq['semester']; ?></td>
        <td><?php echo $pyq['year']; ?></td>
        <td><a href="download-minimal.php?id=<?php echo $pyq['id']; ?>">Download</a></td>
    </tr>
    <?php endforeach; ?>
</table>
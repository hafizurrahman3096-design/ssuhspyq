<?php
// Simple login test without complex includes
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Simple database connection
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'ssuhs_pyq';

$error = '';
$success = '';

if ($_POST) {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';
    
    if (!empty($user) && !empty($pass)) {
        try {
            $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $stmt = $pdo->prepare("SELECT id, username, password FROM admin WHERE username = ?");
            $stmt->execute([$user]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($admin && password_verify($pass, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];
                $success = 'Login successful! You can now access the admin panel.';
            } else {
                $error = 'Invalid username or password';
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    } else {
        $error = 'Please fill in all fields';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Simple Login Test - SSUHS PYQ</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
        button { background: #3498db; color: white; padding: 12px 24px; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #2980b9; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .success { color: #27ae60; background: #d5f4e6; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: #3498db; background: #ebf3fd; padding: 10px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
    <h1>🔐 Simple Login Test</h1>
    
    <?php if ($error): ?>
        <div class="error">❌ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="success">✅ <?php echo htmlspecialchars($success); ?></div>
        <div class="info">
            <p>Now try accessing:</p>
            <ul>
                <li><a href="admin/dashboard.php">Admin Dashboard</a></li>
                <li><a href="backend/auth/login.php">Backend Login</a></li>
                <li><a href="index.html">Main Website</a></li>
            </ul>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['admin_id'])): ?>
        <div class="success">✅ You are already logged in as: <?php echo htmlspecialchars($_SESSION['admin_username']); ?></div>
        <p><a href="admin/dashboard.php">Go to Dashboard</a> | <a href="?logout=1">Logout</a></p>
    <?php endif; ?>
    
    <?php if (isset($_GET['logout'])): ?>
        <?php session_destroy(); ?>
        <div class="info">✅ Logged out successfully</div>
        <script>window.location.href = 'simple-login.php';</script>
    <?php endif; ?>
    
    <form method="POST">
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="admin" required>
        </div>
        
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" value="admin123" required>
        </div>
        
        <button type="submit">Login</button>
    </form>
    
    <div class="info" style="margin-top: 30px;">
        <h3>🔧 Troubleshooting Links:</h3>
        <ul>
            <li><a href="debug.php">Debug Information</a></li>
            <li><a href="setup-database.php">Setup Database</a></li>
            <li><a href="fix-database.php">Fix Database</a></li>
            <li><a href="test-connection.php">Test Connection</a></li>
        </ul>
    </div>
</body>
</html>
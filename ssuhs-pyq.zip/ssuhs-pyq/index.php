<?php
// Redirect to main HTML page or show setup options
if (file_exists('index.html')) {
    header('Location: index.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SSUHS PYQ System Setup</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            max-width: 800px; 
            margin: 50px auto; 
            padding: 20px; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: white;
        }
        .container {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        .btn {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 15px 25px;
            text-decoration: none;
            border-radius: 10px;
            margin: 10px;
            transition: all 0.3s ease;
            border: 1px solid rgba(255,255,255,0.3);
        }
        .btn:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }
        .btn-primary { background: rgba(52, 152, 219, 0.8); }
        .btn-success { background: rgba(39, 174, 96, 0.8); }
        .btn-info { background: rgba(155, 89, 182, 0.8); }
        h1 { text-align: center; margin-bottom: 30px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 30px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🏥 SSUHS PYQ System</h1>
        <p style="text-align: center; font-size: 1.1em; margin-bottom: 30px;">
            Welcome to the SSUHS Previous Year Questions Management System
        </p>
        
        <div class="grid">
            <a href="setup-database.php" class="btn btn-primary">
                🚀 Setup Database<br>
                <small>First time setup</small>
            </a>
            
            <a href="test-connection.php" class="btn btn-success">
                🔍 Test Connection<br>
                <small>Verify database</small>
            </a>
            
            <a href="index.html" class="btn btn-info">
                🌐 Main Website<br>
                <small>Public interface</small>
            </a>
            
            <a href="admin/" class="btn btn-info">
                👨‍💼 Admin Panel<br>
                <small>Manage PYQs</small>
            </a>
        </div>
        
        <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 10px; margin-top: 30px;">
            <h3>📋 Setup Instructions:</h3>
            <ol>
                <li><strong>Start XAMPP:</strong> Ensure Apache and MySQL are running</li>
                <li><strong>Setup Database:</strong> Click "Setup Database" button above</li>
                <li><strong>Test Connection:</strong> Verify everything is working</li>
                <li><strong>Access Website:</strong> Visit the main website or admin panel</li>
            </ol>
        </div>
        
        <div style="background: rgba(39, 174, 96, 0.2); padding: 15px; border-radius: 10px; margin-top: 20px;">
            <h4>🔑 Default Admin Credentials:</h4>
            <p><strong>Username:</strong> admin</p>
            <p><strong>Password:</strong> admin123</p>
        </div>
    </div>
</body>
</html>
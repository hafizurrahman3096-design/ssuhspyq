# SSUHS PYQ - Deployment Guide

## Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)

## Shared Hosting Deployment

### 1. Prepare Files
```bash
# Create deployment package
zip -r ssuhs-pyq.zip . -x "*/.git/*" "*/node_modules/*"
```

### 2. Upload to Hosting
1. Login to cPanel
2. Go to File Manager
3. Upload `ssuhs-pyq.zip`
4. Extract the files
5. Move files to public_html directory

### 3. Database Setup
1. Go to MySQL Database Wizard in cPanel
2. Create new database
3. Create database user
4. Grant all privileges
5. Import your database:
   ```sql
   -- Use phpMyAdmin to import your .sql file
   ```

### 4. Configuration
Update `backend/config/database.php`:
```php
$host = 'localhost';
$dbname = 'your_database_name';
$username = 'your_database_user';
$password = 'your_database_password';
```

### 5. File Permissions
Set proper permissions:
```bash
chmod 755 /path/to/your/files
chmod 644 /path/to/your/php/files
chmod 777 /path/to/uploads/directory
```

## VPS Deployment (Ubuntu)

### 1. Install LAMP Stack
```bash
sudo apt update
sudo apt install apache2 mysql-server php libapache2-mod-php php-mysql
```

### 2. Configure Apache
```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

### 3. Deploy Files
```bash
sudo cp -r /path/to/ssuhs-pyq /var/www/html/
sudo chown -R www-data:www-data /var/www/html/ssuhs-pyq
```

### 4. Database Setup
```bash
sudo mysql_secure_installation
sudo mysql -u root -p
CREATE DATABASE ssuhs_pyq;
CREATE USER 'ssuhs_user'@'localhost' IDENTIFIED BY 'strong_password';
GRANT ALL PRIVILEGES ON ssuhs_pyq.* TO 'ssuhs_user'@'localhost';
FLUSH PRIVILEGES;
```

## Cloud Deployment (Heroku)

### 1. Install Heroku CLI
```bash
npm install -g heroku
```

### 2. Prepare for Heroku
Create `composer.json`:
```json
{
    "require": {
        "php": ">=7.4"
    }
}
```

Create `Procfile`:
```
web: heroku-php-apache2 public/
```

### 3. Deploy
```bash
heroku create your-app-name
git add .
git commit -m "Initial deploy"
git push heroku main
```

## Environment Variables
Set these in your hosting environment:
- `DB_HOST`
- `DB_NAME`
- `DB_USER`
- `DB_PASSWORD`

## Security Considerations
1. Change default admin credentials
2. Use HTTPS (SSL certificate)
3. Hide PHP errors in production
4. Regular backups
5. Update dependencies

## Testing After Deployment
1. Test login functionality
2. Test file uploads
3. Test all CRUD operations
4. Check responsive design
5. Verify database connections

## Troubleshooting
- **500 Internal Server Error**: Check .htaccess and PHP logs
- **Database Connection Failed**: Verify credentials
- **File Upload Issues**: Check directory permissions
- **Blank Pages**: Enable PHP error logging

# SSUHS Board PYQ Website

A complete website for managing Previous Year Questions (PYQ) for SSUHS (Srimanta Sankaradeva University of Health Sciences) board courses including MBBS, BSC Nursing, and BMLT.

## Features

### Public Website
- Clean, responsive design
- Course-wise PYQ browsing (MBBS, BSC Nursing, BMLT)
- **NEW: Semester-wise organization** for all departments (Semester 1-8)
- Filter by semester, year, and subject
- Download PYQ files
- Mobile-friendly interface

### Admin Panel
- **NEW: Backend authentication system**
- Secure admin login moved to backend
- Dashboard with statistics
- Add new PYQ with file upload (now includes semester selection)
- Manage existing PYQs (edit/delete)
- Search and filter functionality
- File management system

## Installation

### Requirements
- Web server (Apache/Nginx)
- PHP 7.4 or higher
- MySQL 5.7 or higher
- mod_rewrite enabled (for Apache)

### Setup Steps

1. **Upload Files**
   - Upload all files to your web server directory
   - Ensure the `uploads/` directory has write permissions (755 or 777)

2. **Database Setup**
   - The database and tables will be created automatically on first run
   - **Run migration**: Visit `http://localhost/ssuhs-pyq/backend/migrate.php` to update database schema

3. **Admin Access**
   - **NEW URL**: `http://localhost/ssuhs-pyq/admin` (redirects to backend login)
   - Direct URL: `http://localhost/ssuhs-pyq/backend/auth/login.php`
   - Username: `admin`
   - Password: `admin123`

4. **File Permissions**
   ```bash
   chmod 755 uploads/
   chmod 644 uploads/.htaccess
   ```

## File Structure

```
├── index.html              # Main public website (admin login removed)
├── css/
│   ├── style.css          # Public website styles
│   └── admin.css          # Admin panel styles
├── js/
│   └── script.js          # Frontend JavaScript (updated with semester support)
├── backend/               # NEW: Backend system
│   ├── config/
│   │   └── database.php   # Database configuration (updated schema)
│   ├── auth/
│   │   ├── login.php      # Admin login (moved from admin/)
│   │   └── logout.php     # Admin logout (moved from admin/)
│   ├── api/
│   │   └── get_pyq.php    # API to fetch PYQs (updated with semester support)
│   └── migrate.php        # Database migration script
├── admin/
│   ├── dashboard.php      # Admin dashboard (updated)
│   ├── add_pyq.php        # Add new PYQ (updated with semester)
│   ├── manage_pyq.php     # Manage existing PYQs (updated)
│   └── delete_pyq.php     # Delete PYQ (updated)
├── uploads/               # PYQ file storage
│   └── .htaccess         # Security rules
├── .htaccess             # NEW: URL rewriting for admin access
└── README.md             # This file
```

## Changes Made

### 1. Backend Authentication System
- Moved admin login from `/admin/login.php` to `/backend/auth/login.php`
- Admin panel now accessible via `localhost/ssuhs-pyq/admin`
- Centralized authentication handling

### 2. Semester Support
- Added semester field to database (1-8 semesters)
- Updated all admin forms to include semester selection
- Enhanced filtering with semester options
- Updated API to support semester-based queries

### 3. Fixed Button Functionality
- Updated API endpoints to use backend structure
- Fixed all navigation and form submissions
- Corrected file paths and references

### 4. Enhanced User Experience
- Removed admin login from main navigation
- Added semester filter to public interface
- Improved PYQ display with semester information
- Better organization of question papers

## Usage

### For Students
1. Visit the website
2. Click on desired course (MBBS, BSC Nursing, BMLT)
3. **NEW**: Filter by semester (1-8), year, and subject
4. Download question papers organized by semester

### For Administrators
1. Go to `/admin` or `/backend/auth/login.php`
2. Login with admin credentials
3. Use dashboard to:
   - View statistics
   - Add new PYQs with semester selection
   - Manage existing content
   - Search and filter PYQs

## Database Schema Updates

#### PYQ Table (Updated)
- id (Primary Key)
- title
- course (enum: mbbs, bsc-nursing, bmlt)
- subject
- **semester (NEW: INT 1-8)**
- year
- description
- file_path
- uploaded_by (Foreign Key to admin.id)
- created_at

## Manual Cleanup Required

Please manually delete these old files (system prevented automatic deletion):
- `admin/login.php` (moved to `backend/auth/login.php`)
- `admin/logout.php` (moved to `backend/auth/logout.php`)

## Troubleshooting

### Migration Issues
1. **Run Migration Script**: Visit `http://localhost/ssuhs-pyq/backend/migrate.php`
2. **Database Schema**: Ensure semester column exists in pyq table
3. **File Paths**: Update any hardcoded paths to use new backend structure

### Common Issues
1. **Admin Access**: Use new URL `localhost/ssuhs-pyq/admin`
2. **API Endpoints**: Updated to use `/backend/api/` structure
3. **File Uploads**: Ensure uploads directory permissions are correct

## License
This project is open source and available under the MIT License.

## Support
For support and questions, please contact the system administrator.
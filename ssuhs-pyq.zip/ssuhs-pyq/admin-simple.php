<?php
session_start();

// Simple login check
if (!isset($_SESSION['admin_logged_in'])) {
    if ($_POST && $_POST['username'] == 'admin' && $_POST['password'] == 'admin123') {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = 'admin';
    }
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin-simple.php');
    exit;
}

// Database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'ssuhs_pyq';

$stats = [];
$pyqs = [];

if (isset($_SESSION['admin_logged_in'])) {
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Get stats
        $stats['mbbs'] = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'mbbs'")->fetchColumn();
        $stats['nursing'] = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'bsc-nursing'")->fetchColumn();
        $stats['bmlt'] = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'bmlt'")->fetchColumn();
        $stats['pharmacy'] = $pdo->query("SELECT COUNT(*) FROM pyq WHERE course = 'pharmacy'")->fetchColumn();
        $stats['total'] = array_sum($stats);
        
        // Get recent PYQs
        $pyqs = $pdo->query("SELECT * FROM pyq ORDER BY created_at DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Simple Admin - SSUHS PYQ</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; }
        .header { background: #2c3e50; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        .login-form { background: white; padding: 30px; border-radius: 5px; max-width: 400px; margin: 50px auto; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 3px; }
        .btn { background: #3498db; color: white; padding: 10px 20px; border: none; border-radius: 3px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn:hover { background: #2980b9; }
        .btn-danger { background: #e74c3c; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 5px; text-align: center; }
        .stat-card h3 { margin: 0; font-size: 2em; color: #3498db; }
        .table-container { background: white; padding: 20px; border-radius: 5px; }
        .table { width: 100%; border-collapse: collapse; }
        .table th, .table td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        .table th { background: #f8f9fa; }
        .error { color: #e74c3c; background: #fdf2f2; padding: 10px; border-radius: 3px; margin: 10px 0; }
    </style>
</head>
<body>

<?php if (!isset($_SESSION['admin_logged_in'])): ?>
    <div class="login-form">
        <h2>🔐 Admin Login</h2>
        <form method="POST">
            <div class="form-group">
                <label>Username:</label>
                <input type="text" name="username" value="admin" required>
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="password" value="admin123" required>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>
        <p><small>Default: admin / admin123</small></p>
    </div>
<?php else: ?>
    <div class="container">
        <div class="header">
            <h1>🏥 SSUHS PYQ Admin Panel</h1>
            <p>Welcome, <?php echo $_SESSION['admin_username']; ?> | 
               <a href="?logout=1" style="color: white;">Logout</a></p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="error">❌ Error: <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <div class="stats">
            <div class="stat-card">
                <h3><?php echo $stats['mbbs'] ?? 0; ?></h3>
                <p>MBBS</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['nursing'] ?? 0; ?></h3>
                <p>BSC Nursing</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['bmlt'] ?? 0; ?></h3>
                <p>BMLT</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['pharmacy'] ?? 0; ?></h3>
                <p>Pharmacy</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['total'] ?? 0; ?></h3>
                <p>Total</p>
            </div>
        </div>
        
        <div class="table-container">
            <h2>📋 Recent PYQs</h2>
            <?php if (!empty($pyqs)): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Course</th>
                            <th>Subject</th>
                            <th>Semester</th>
                            <th>Year</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pyqs as $pyq): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($pyq['title']); ?></td>
                                <td><?php echo strtoupper($pyq['course']); ?></td>
                                <td><?php echo htmlspecialchars($pyq['subject']); ?></td>
                                <td><?php echo $pyq['semester']; ?></td>
                                <td><?php echo $pyq['year']; ?></td>
                                <td>
                                    <a href="download-simple.php?id=<?php echo $pyq['id']; ?>" class="btn" style="padding: 5px 10px; font-size: 0.8em;">
                                        📥 Download
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No PYQs found. <a href="simple-setup.php">Run setup</a> to add sample data.</p>
            <?php endif; ?>
        </div>
        
        <div style="margin-top: 30px; text-align: center;">
            <a href="add-pyq-simple.php" class="btn">➕ Add New PYQ</a>
            <a href="view-pyq.php" class="btn">👁️ View Public Site</a>
            <a href="simple-setup.php" class="btn">🔧 Run Setup</a>
        </div>
    </div>
<?php endif; ?>

</body>
</html>
<?php
// Simple database configuration - no complex initialization
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'ssuhs_pyq';

function connectDB() {
    global $db_host, $db_user, $db_pass, $db_name;
    
    try {
        $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    } catch(PDOException $e) {
        die("Database connection failed. Please import the ssuhs_pyq.sql file first. Error: " . $e->getMessage());
    }
}
?>